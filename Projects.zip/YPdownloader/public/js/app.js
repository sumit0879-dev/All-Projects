// Global State
let currentPlaylistData = null;
let eventSource = null;

document.addEventListener('DOMContentLoaded', () => {
  initEventListeners();
  loadCompletedFiles();
});

function initEventListeners() {
  // Form submission
  const form = document.getElementById('playlist-form');
  form.addEventListener('submit', handleFetchPlaylist);

  // Selection tools
  document.getElementById('btn-select-all').addEventListener('click', selectAllVideos);
  document.getElementById('btn-deselect-all').addEventListener('click', deselectAllVideos);

  // Search filter
  document.getElementById('video-search').addEventListener('input', handleSearchFilter);

  // Start Download
  document.getElementById('btn-download-start').addEventListener('click', startDownloadSession);

  // Close Progress Modal
  document.getElementById('btn-close-progress').addEventListener('click', closeProgressModal);

  // Folder Picker Events
  document.getElementById('btn-browse-folder').addEventListener('click', openFolderPicker);
  document.getElementById('btn-close-folder-picker').addEventListener('click', closeFolderPicker);
  document.getElementById('btn-folder-up').addEventListener('click', navigateFolderUp);
  document.getElementById('btn-folder-drives').addEventListener('click', loadDrives);
  document.getElementById('btn-folder-select').addEventListener('click', confirmFolderSelection);

  // Refresh files
  document.getElementById('btn-refresh-files').addEventListener('click', loadCompletedFiles);

  // Update yt-dlp button
  document.getElementById('btn-update-ytdlp').addEventListener('click', handleUpdateYtDlp);
}

// -------------------------------------------------------------
// 1. Fetch Playlist Metadata
// -------------------------------------------------------------
async function handleFetchPlaylist(e) {
  e.preventDefault();
  const urlInput = document.getElementById('playlist-url');
  const url = urlInput.value.trim();
  if (!url) return;

  const fetchBtn = document.getElementById('fetch-btn');
  const btnText = fetchBtn.querySelector('.btn-text');
  const btnIcon = fetchBtn.querySelector('.btn-icon');
  const spinner = fetchBtn.querySelector('.spinner');

  // Loading UI state
  fetchBtn.disabled = true;
  btnText.textContent = 'Fetching...';
  btnIcon.classList.add('hidden');
  spinner.classList.remove('hidden');

  hideStatusBanner();

  try {
    const response = await fetch('/api/playlist-info', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Failed to fetch playlist data');
    }

    currentPlaylistData = data;
    renderPlaylistWorkspace(data);
    showStatusBanner(`Successfully loaded ${data.totalVideos} video(s)!`, 'success');
  } catch (err) {
    showStatusBanner(err.message || 'Error connecting to server', 'error');
  } finally {
    fetchBtn.disabled = false;
    btnText.textContent = 'Fetch Playlist';
    btnIcon.classList.remove('hidden');
    spinner.classList.add('hidden');
  }
}

// -------------------------------------------------------------
// 2. Render Workspace & Video Grid
// -------------------------------------------------------------
function renderPlaylistWorkspace(data) {
  const workspace = document.getElementById('workspace');
  workspace.classList.remove('hidden');

  // Render Metadata
  document.getElementById('meta-thumb').src = data.thumbnail || 'https://via.placeholder.com/320x180';
  document.getElementById('meta-title').textContent = data.title;
  document.getElementById('meta-uploader').textContent = data.uploader;
  document.getElementById('stat-total').textContent = data.totalVideos;
  document.getElementById('meta-count-badge').textContent = `${data.totalVideos} Videos`;

  // Render Video Grid Cards
  const videoGrid = document.getElementById('video-grid');
  videoGrid.innerHTML = '';

  data.videos.forEach((video) => {
    const card = document.createElement('div');
    card.className = 'video-card selected';
    card.dataset.id = video.id;
    card.dataset.title = video.title.toLowerCase();

    card.innerHTML = `
      <input type="checkbox" class="card-checkbox" checked data-id="${video.id}" data-index="${video.index}" />
      <div class="card-thumb-wrapper">
        <img src="${video.thumbnail}" alt="${escapeHtml(video.title)}" loading="lazy" />
        <span class="duration-tag">${video.durationFormatted}</span>
      </div>
      <div class="card-content">
        <h4 class="video-card-title">${escapeHtml(video.title)}</h4>
        <div class="video-card-meta">
          <span>#${video.index} • ${escapeHtml(video.uploader)}</span>
        </div>
      </div>
    `;

    // Click on card toggles checkbox
    card.addEventListener('click', (e) => {
      if (e.target.tagName !== 'INPUT') {
        const cb = card.querySelector('.card-checkbox');
        cb.checked = !cb.checked;
      }
      updateCardSelectionState(card);
      updateSelectedCount();
    });

    videoGrid.appendChild(card);
  });

  updateSelectedCount();

  // Scroll smoothly to workspace
  workspace.scrollIntoView({ behavior: 'smooth' });
}

function updateCardSelectionState(card) {
  const cb = card.querySelector('.card-checkbox');
  if (cb.checked) {
    card.classList.add('selected');
  } else {
    card.classList.remove('selected');
  }
}

function selectAllVideos() {
  document.querySelectorAll('.video-card').forEach(card => {
    const cb = card.querySelector('.card-checkbox');
    cb.checked = true;
    card.classList.add('selected');
  });
  updateSelectedCount();
}

function deselectAllVideos() {
  document.querySelectorAll('.video-card').forEach(card => {
    const cb = card.querySelector('.card-checkbox');
    cb.checked = false;
    card.classList.remove('selected');
  });
  updateSelectedCount();
}

function updateSelectedCount() {
  const checkboxes = document.querySelectorAll('.card-checkbox:checked');
  document.getElementById('stat-selected').textContent = checkboxes.length;
}

function handleSearchFilter(e) {
  const query = e.target.value.toLowerCase().trim();
  document.querySelectorAll('.video-card').forEach(card => {
    const title = card.dataset.title;
    if (title.includes(query)) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

// -------------------------------------------------------------
// 3. Trigger Real-Time SSE Download Stream
// -------------------------------------------------------------
function startDownloadSession() {
  const url = document.getElementById('playlist-url').value.trim();
  if (!url) {
    showStatusBanner('Please fetch a playlist first.', 'error');
    return;
  }

  if (!currentPlaylistData) {
    showStatusBanner('Playlist data is missing. Please fetch the playlist again.', 'error');
    return;
  }

  const quality = document.getElementById('quality-select')?.value || 'best';
  const format = document.getElementById('format-select')?.value || 'mp4';
  const subtitles = document.getElementById('opt-subtitles')?.checked || false;
  const thumbnails = document.getElementById('opt-thumbnails')?.checked || false;
  const downloadDir = document.getElementById('download-dir-input')?.value.trim() || '';

  const allCheckboxes = document.querySelectorAll('.card-checkbox');
  const checkedCheckboxes = document.querySelectorAll('.card-checkbox:checked');

  if (checkedCheckboxes.length === 0) {
    showStatusBanner('Please select at least one video to download.', 'error');
    return;
  }

  const isSelectAll = (checkedCheckboxes.length === allCheckboxes.length).toString();
  const videoIndices = Array.from(checkedCheckboxes).map(cb => cb.dataset.index).join(',');

  // Reset Progress Modal UI
  openProgressModal();
  updateProgressUI(0, '0 MB/s', 'ETA: --:--', 'Initializing download process...');
  document.getElementById('console-log').textContent = 'Connecting to download stream...\n';

  // Construct SSE query URL
  const queryParams = new URLSearchParams({
    url,
    videoIndices,
    isSelectAll,
    quality,
    format,
    subtitles: subtitles.toString(),
    thumbnails: thumbnails.toString(),
    downloadDir
  });

  if (eventSource) {
    eventSource.close();
  }

  eventSource = new EventSource(`/api/download-stream?${queryParams.toString()}`);

  eventSource.addEventListener('start', (e) => {
    const data = JSON.parse(e.data);
    appendConsoleLog(`[START] ${data.message}`);
  });

  eventSource.addEventListener('item-change', (e) => {
    const data = JSON.parse(e.data);
    document.getElementById('current-item-label').textContent = `Processing Video ${data.currentIndex} of ${data.totalItems}`;
    appendConsoleLog(`[ITEM] Video ${data.currentIndex}/${data.totalItems}`);
  });

  eventSource.addEventListener('video-title', (e) => {
    const data = JSON.parse(e.data);
    document.getElementById('current-file-name').textContent = data.title;
  });

  eventSource.addEventListener('progress', (e) => {
    const data = JSON.parse(e.data);
    updateProgressUI(data.percent, data.speed, `ETA: ${data.eta}`, data.currentVideo);
  });

  eventSource.addEventListener('log', (e) => {
    const data = JSON.parse(e.data);
    appendConsoleLog(data.message);
  });

  eventSource.addEventListener('complete', (e) => {
    const data = JSON.parse(e.data);
    updateProgressUI(100, 'Done', 'Complete!', 'All downloads completed successfully.');
    appendConsoleLog(`[SUCCESS] ${data.message}`);
    eventSource.close();
    eventSource = null;
    loadCompletedFiles();
  });

  eventSource.addEventListener('error', (e) => {
    // Check if this is a yt-dlp-sent error event (not browser EventSource error)
    try {
      if (e.data) {
        const data = JSON.parse(e.data);
        if (data.errorType === '403_FORBIDDEN') {
          appendConsoleLog(`[ERROR] ${data.message}`);
          updateProgressUI(0, 'Failed', 'Error!', `${data.errorCount} video(s) blocked by YouTube (403 Forbidden)`);
          showStatusBanner(
            `⚠️ YouTube blocked downloads (403 Forbidden). Fix: 1) Open YouTube in browser & sign in, 2) Click "Update yt-dlp" button in header, 3) Try again.`,
            'error'
          );
        } else {
          appendConsoleLog(`[ERROR] ${data.message}`);
        }
        if (eventSource) {
          eventSource.close();
          eventSource = null;
        }
        loadCompletedFiles();
        return;
      }
    } catch (parseErr) {
      // Not a JSON data event, it's a connection error
    }
    
    appendConsoleLog('[NOTICE] Stream ended or connection closed.');
    if (eventSource) {
      eventSource.close();
      eventSource = null;
    }
    loadCompletedFiles();
  });
}

function updateProgressUI(percent, speed, eta, fileName) {
  const fill = document.getElementById('progress-fill');
  fill.style.width = `${percent}%`;

  document.getElementById('progress-percent').textContent = `${Math.round(percent)}%`;
  document.getElementById('progress-speed').innerHTML = `<i class="fa-solid fa-gauge-high"></i> ${speed}`;
  document.getElementById('progress-eta').innerHTML = `<i class="fa-solid fa-clock"></i> ${eta}`;

  if (fileName) {
    document.getElementById('current-file-name').textContent = fileName;
  }
}

function appendConsoleLog(msg) {
  const consoleLog = document.getElementById('console-log');
  consoleLog.textContent += msg + '\n';
  const body = document.getElementById('console-body');
  body.scrollTop = body.scrollHeight;
}

function toggleConsoleLog() {
  const body = document.getElementById('console-body');
  const chevron = document.getElementById('console-chevron');
  if (body.style.display === 'none') {
    body.style.display = 'block';
    chevron.className = 'fa-solid fa-chevron-down';
  } else {
    body.style.display = 'none';
    chevron.className = 'fa-solid fa-chevron-up';
  }
}

function openProgressModal() {
  document.getElementById('progress-modal').classList.remove('hidden');
}

function closeProgressModal() {
  if (eventSource) {
    eventSource.close();
    eventSource = null;
  }
  document.getElementById('progress-modal').classList.add('hidden');
}

// -------------------------------------------------------------
// 4. Completed Files Section
// -------------------------------------------------------------
async function loadCompletedFiles() {
  const completedSection = document.getElementById('completed-section');
  const filesList = document.getElementById('files-list');

  try {
    const res = await fetch('/api/files');
    const data = await res.json();

    if (data.files && data.files.length > 0) {
      completedSection.classList.remove('hidden');
      filesList.innerHTML = '';

      data.files.forEach(file => {
        const item = document.createElement('div');
        item.className = 'file-item';
        item.innerHTML = `
          <div class="file-info">
            <i class="fa-solid fa-file-video text-success"></i>
            <span class="file-name-text">${escapeHtml(file.name)}</span>
            <span class="file-size-badge">${file.size}</span>
          </div>
          <a href="${file.downloadUrl}" download class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-download"></i> Save File
          </a>
        `;
        filesList.appendChild(item);
      });
    }
  } catch (err) {
    console.error('Failed to load completed files list:', err);
  }
}

// Helpers
function showStatusBanner(message, type = 'error') {
  const banner = document.getElementById('status-banner');
  const text = banner.querySelector('.banner-text');
  banner.className = `status-banner ${type}`;
  text.textContent = message;
  banner.classList.remove('hidden');
}

function hideStatusBanner() {
  document.getElementById('status-banner').classList.add('hidden');
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, function(m) {
    return {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    }[m];
  });
}

// -------------------------------------------------------------
// 5. Folder Picker Logic
// -------------------------------------------------------------
let currentExplorerPath = '';
let selectedExplorerPath = '';

async function openFolderPicker() {
  document.getElementById('folder-picker-modal').classList.remove('hidden');
  const inputVal = document.getElementById('download-dir-input').value.trim();
  if (inputVal) {
    await loadFolders(inputVal);
  } else {
    await loadDrives();
  }
}

function closeFolderPicker() {
  document.getElementById('folder-picker-modal').classList.add('hidden');
}

async function loadDrives() {
  currentExplorerPath = '';
  selectedExplorerPath = '';
  document.getElementById('folder-picker-path').textContent = 'Available Drives';
  document.getElementById('btn-folder-up').disabled = true;
  document.getElementById('btn-folder-select').disabled = true;
  
  const list = document.getElementById('folder-list');
  list.innerHTML = '<div class="folder-item"><i class="fa-solid fa-spinner fa-spin"></i> Loading...</div>';
  
  try {
    const res = await fetch('/api/drives');
    const data = await res.json();
    
    list.innerHTML = '';
    if (data.drives && data.drives.length > 0) {
      data.drives.forEach(drive => {
        const item = document.createElement('div');
        item.className = 'folder-item';
        item.innerHTML = `<i class="fa-solid fa-hard-drive"></i> ${drive}`;
        item.addEventListener('click', () => loadFolders(drive));
        list.appendChild(item);
      });
    } else {
      list.innerHTML = '<div class="folder-item">No drives found</div>';
    }
  } catch (e) {
    list.innerHTML = '<div class="folder-item text-danger">Failed to load drives</div>';
  }
}

async function loadFolders(targetPath) {
  const list = document.getElementById('folder-list');
  list.innerHTML = '<div class="folder-item"><i class="fa-solid fa-spinner fa-spin"></i> Loading...</div>';
  
  try {
    const res = await fetch(`/api/folders?path=${encodeURIComponent(targetPath)}`);
    const data = await res.json();
    
    if (!res.ok) throw new Error(data.error);
    
    currentExplorerPath = data.currentPath;
    selectedExplorerPath = currentExplorerPath;
    
    document.getElementById('folder-picker-path').textContent = currentExplorerPath;
    document.getElementById('btn-folder-up').disabled = false;
    document.getElementById('btn-folder-select').disabled = false;
    
    list.innerHTML = '';
    
    if (data.folders && data.folders.length > 0) {
      data.folders.forEach(folder => {
        const item = document.createElement('div');
        item.className = 'folder-item';
        item.innerHTML = `<i class="fa-solid fa-folder"></i> ${escapeHtml(folder.name)}`;
        
        // Single click selects, double click opens
        let clicks = 0;
        item.addEventListener('click', (e) => {
          clicks++;
          if (clicks === 1) {
            setTimeout(() => {
              if (clicks === 1) {
                // Select
                document.querySelectorAll('.folder-item').forEach(el => el.classList.remove('selected'));
                item.classList.add('selected');
                selectedExplorerPath = folder.path;
              }
              clicks = 0;
            }, 250); // 250ms for double click detection
          } else {
            // Double click: open folder
            loadFolders(folder.path);
          }
        });
        
        list.appendChild(item);
      });
    } else {
      list.innerHTML = '<div class="folder-item text-muted"><em>Empty folder</em></div>';
    }
  } catch (e) {
    list.innerHTML = `<div class="folder-item text-danger"><i class="fa-solid fa-triangle-exclamation"></i> ${escapeHtml(e.message)}</div>`;
    selectedExplorerPath = currentExplorerPath; // keep current
    document.getElementById('btn-folder-select').disabled = false;
  }
}

function navigateFolderUp() {
  if (!currentExplorerPath) return;
  // Basic up navigation (remove last path segment)
  let parentPath = currentExplorerPath.replace(/\\/g, '/');
  if (parentPath.endsWith('/')) parentPath = parentPath.slice(0, -1);
  const parts = parentPath.split('/');
  if (parts.length <= 1) {
    loadDrives(); // reached root
  } else {
    parts.pop();
    loadFolders(parts.join('/') + '/');
  }
}

function confirmFolderSelection() {
  if (selectedExplorerPath) {
    document.getElementById('download-dir-input').value = selectedExplorerPath;
  }
  closeFolderPicker();
}

// -------------------------------------------------------------
// 6. yt-dlp Update Handler
// -------------------------------------------------------------
async function handleUpdateYtDlp() {
  const btn = document.getElementById('btn-update-ytdlp');
  const originalHTML = btn.innerHTML;
  
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Updating...';
  
  try {
    const res = await fetch('/api/update-ytdlp', { method: 'POST' });
    const data = await res.json();
    
    if (data.success) {
      showStatusBanner(`✅ ${data.message}`, 'success');
      btn.innerHTML = '<i class="fa-solid fa-check"></i> Updated!';
      setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.disabled = false;
      }, 3000);
    } else {
      showStatusBanner(`❌ ${data.message || 'Update failed'}`, 'error');
      btn.innerHTML = originalHTML;
      btn.disabled = false;
    }
  } catch (err) {
    showStatusBanner(`❌ Update failed: ${err.message}`, 'error');
    btn.innerHTML = originalHTML;
    btn.disabled = false;
  }
}
