const fs = require('fs');
const path = require('path');
const https = require('https');
const { execSync } = require('child_process');

const BIN_DIR = path.join(__dirname, '..', 'bin');
const YTDLP_PATH = path.join(BIN_DIR, 'yt-dlp.exe');
const FFMPEG_PATH = path.join(BIN_DIR, 'ffmpeg.exe');

// Use yt-dlp nightly for latest fixes (YouTube changes frequently)
const YTDLP_URL = 'https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download/yt-dlp.exe';
const YTDLP_STABLE_URL = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe';
const FFMPEG_ZIP_URL = 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip';

// Max age before auto-update (3 days in milliseconds)
const MAX_BINARY_AGE_MS = 3 * 24 * 60 * 60 * 1000;

/**
 * Download a binary file from URL with HTTP redirect support
 */
function downloadFile(url, destPath, forceRedownload = false) {
  return new Promise((resolve, reject) => {
    if (fs.existsSync(destPath) && !forceRedownload) {
      console.log(`[BinaryManager] Binary exists at: ${destPath}`);
      return resolve(destPath);
    }

    // Remove old file if force re-downloading
    if (fs.existsSync(destPath) && forceRedownload) {
      try { fs.unlinkSync(destPath); } catch (e) {}
    }

    console.log(`[BinaryManager] Downloading binary from ${url}...`);
    const file = fs.createWriteStream(destPath);

    function request(targetUrl, redirectCount = 0) {
      if (redirectCount > 10) {
        fs.unlink(destPath, () => {});
        return reject(new Error('Too many redirects'));
      }

      https.get(targetUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      }, (response) => {
        if (response.statusCode === 301 || response.statusCode === 302 || response.statusCode === 307) {
          return request(response.headers.location, redirectCount + 1);
        }

        if (response.statusCode !== 200) {
          fs.unlink(destPath, () => {});
          return reject(new Error(`Failed to download binary: HTTP ${response.statusCode}`));
        }

        response.pipe(file);

        file.on('finish', () => {
          file.close(() => {
            console.log(`[BinaryManager] Download complete: ${destPath}`);
            resolve(destPath);
          });
        });
      }).on('error', (err) => {
        fs.unlink(destPath, () => {});
        reject(err);
      });
    }

    request(url);
  });
}

/**
 * Check if yt-dlp binary is outdated (older than MAX_BINARY_AGE_MS)
 */
function isBinaryOutdated(binaryPath) {
  try {
    if (!fs.existsSync(binaryPath)) return true;
    const stat = fs.statSync(binaryPath);
    const ageMs = Date.now() - stat.mtimeMs;
    return ageMs > MAX_BINARY_AGE_MS;
  } catch (e) {
    return true;
  }
}

/**
 * Forces yt-dlp to update itself using its built-in --update mechanism
 */
async function updateYtDlp() {
  console.log('[BinaryManager] Updating yt-dlp to latest version...');
  
  // First try self-update
  try {
    const result = execSync(`"${YTDLP_PATH}" --update`, { 
      timeout: 60000, 
      encoding: 'utf8',
      stdio: ['pipe', 'pipe', 'pipe'] 
    });
    console.log('[BinaryManager] yt-dlp self-update result:', result.trim());
    return true;
  } catch (err) {
    console.log('[BinaryManager] Self-update failed, re-downloading fresh binary...');
  }
  
  // Fallback: re-download from nightly
  try {
    await downloadFile(YTDLP_URL, YTDLP_PATH, true);
    console.log('[BinaryManager] Successfully downloaded latest yt-dlp nightly build');
    return true;
  } catch (err) {
    console.log('[BinaryManager] Nightly download failed, trying stable release...');
  }

  // Fallback: stable release
  try {
    await downloadFile(YTDLP_STABLE_URL, YTDLP_PATH, true);
    console.log('[BinaryManager] Successfully downloaded latest yt-dlp stable build');
    return true;
  } catch (err) {
    console.error('[BinaryManager] All update methods failed:', err.message);
    return false;
  }
}

/**
 * Ensures yt-dlp.exe exists locally and is up-to-date
 */
async function ensureYtDlp() {
  if (!fs.existsSync(BIN_DIR)) {
    fs.mkdirSync(BIN_DIR, { recursive: true });
  }

  const needsDownload = !fs.existsSync(YTDLP_PATH);
  const needsUpdate = isBinaryOutdated(YTDLP_PATH);

  if (needsDownload) {
    // Try nightly first, then stable
    try {
      await downloadFile(YTDLP_URL, YTDLP_PATH);
    } catch (err) {
      console.log('[BinaryManager] Nightly download failed, trying stable...');
      await downloadFile(YTDLP_STABLE_URL, YTDLP_PATH);
    }
  } else if (needsUpdate) {
    console.log('[BinaryManager] yt-dlp binary is outdated, updating...');
    await updateYtDlp();
  } else {
    console.log(`[BinaryManager] yt-dlp binary is up-to-date at: ${YTDLP_PATH}`);
  }

  await ensureFfmpeg();
  return YTDLP_PATH;
}

/**
 * Ensures ffmpeg.exe exists locally in ./bin/ffmpeg.exe
 */
async function ensureFfmpeg() {
  if (fs.existsSync(FFMPEG_PATH)) {
    console.log(`[BinaryManager] ffmpeg.exe found at: ${FFMPEG_PATH}`);
    return FFMPEG_PATH;
  }

  console.log('[BinaryManager] ffmpeg.exe missing. Downloading FFmpeg static binary bundle...');
  const zipPath = path.join(BIN_DIR, 'ffmpeg.zip');
  
  try {
    await downloadFile(FFMPEG_ZIP_URL, zipPath);
    console.log('[BinaryManager] Extracting ffmpeg.exe using PowerShell...');
    const extractCmd = `powershell -Command "Expand-Archive -Path '${zipPath}' -DestinationPath '${BIN_DIR}\\temp_ffmpeg' -Force; Get-ChildItem -Path '${BIN_DIR}\\temp_ffmpeg' -Filter 'ffmpeg.exe' -Recurse | Copy-Item -Destination '${FFMPEG_PATH}'; Remove-Item -Path '${BIN_DIR}\\temp_ffmpeg' -Recurse -Force; Remove-Item -Path '${zipPath}' -Force"`;
    execSync(extractCmd);
    console.log(`[BinaryManager] ffmpeg.exe ready at: ${FFMPEG_PATH}`);
  } catch (err) {
    console.error('[BinaryManager] FFmpeg download/extraction error:', err.message);
  }
  return FFMPEG_PATH;
}

function getYtDlpPath() {
  return YTDLP_PATH;
}

function getFfmpegPath() {
  if (fs.existsSync(FFMPEG_PATH)) {
    return FFMPEG_PATH;
  }
  return 'ffmpeg';
}

module.exports = {
  ensureYtDlp,
  ensureFfmpeg,
  updateYtDlp,
  getYtDlpPath,
  getFfmpegPath,
  BIN_DIR
};
