const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const { spawn, execFile } = require('child_process');
const { ensureYtDlp, getYtDlpPath, getFfmpegPath, updateYtDlp } = require('./utils/binaryManager');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DOWNLOADS_DIR = path.join(__dirname, 'downloads');

// Ensure downloads directory exists
if (!fs.existsSync(DOWNLOADS_DIR)) {
  fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
}

// MIME Types Map
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mkv': 'video/x-matroska',
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.wav': 'audio/wav',
  '.srt': 'text/plain',
  '.vtt': 'text/vtt'
};

const server = http.createServer(async (req, res) => {
  const host = req.headers.host || `localhost:${PORT}`;
  const reqUrl = new URL(req.url, `http://${host}`);
  const pathname = reqUrl.pathname;
  const method = req.method.toUpperCase();

  // CORS Headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // -------------------------------------------------------------
  // 1. API: Fetch Playlist Info (POST /api/playlist-info)
  // -------------------------------------------------------------
  if (pathname === '/api/playlist-info' && method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        const { url: targetUrl } = JSON.parse(body || '{}');
        if (!targetUrl) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: 'Playlist or Video URL is required' }));
        }

        const ytdlp = getYtDlpPath();
        const args = [
          '--flat-playlist',
          '--dump-single-json',
          '--no-warnings',
          '--skip-download',
          '--extractor-retries', '5',
          '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
          targetUrl
        ];

        console.log('[API] Extracting metadata for:', targetUrl);

        execFile(ytdlp, args, { maxBuffer: 1024 * 1024 * 50 }, (error, stdout, stderr) => {
          if (error) {
            console.error('[API] Metadata extraction error:', stderr || error.message);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({
              error: 'Failed to extract YouTube playlist metadata. Please check the URL.',
              details: stderr || error.message
            }));
          }

          try {
            const data = JSON.parse(stdout);
            const isPlaylist = data._type === 'playlist' || Array.isArray(data.entries);
            let videos = [];

            if (isPlaylist && data.entries) {
              videos = data.entries
                .filter(entry => entry && entry.id)
                .map((entry, index) => ({
                  id: entry.id,
                  title: entry.title || `Video #${index + 1}`,
                  duration: entry.duration || 0,
                  durationFormatted: formatDuration(entry.duration || 0),
                  thumbnail: entry.thumbnails && entry.thumbnails.length > 0
                    ? entry.thumbnails[entry.thumbnails.length - 1].url
                    : `https://i.ytimg.com/vi/${entry.id}/hqdefault.jpg`,
                  url: entry.url || `https://www.youtube.com/watch?v=${entry.id}`,
                  uploader: entry.uploader || entry.channel || data.uploader || data.channel || 'Unknown',
                  index: index + 1
                }));
            } else {
              videos = [{
                id: data.id,
                title: data.title,
                duration: data.duration || 0,
                durationFormatted: formatDuration(data.duration || 0),
                thumbnail: data.thumbnail || `https://i.ytimg.com/vi/${data.id}/hqdefault.jpg`,
                url: data.webpage_url || `https://www.youtube.com/watch?v=${data.id}`,
                uploader: data.uploader || data.channel || 'Unknown',
                index: 1
              }];
            }

            const result = {
              title: data.title || 'YouTube Playlist',
              uploader: data.uploader || data.channel || 'YouTube Creator',
              totalVideos: videos.length,
              thumbnail: videos[0]?.thumbnail || '',
              videos
            };

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(result));
          } catch (parseErr) {
            console.error('[API] Parse error:', parseErr);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Failed to parse YouTube metadata JSON' }));
          }
        });
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON request payload' }));
      }
    });
    return;
  }

  // -------------------------------------------------------------
  // 2. API: Download Stream SSE (GET /api/download-stream)
  // -------------------------------------------------------------
  if (pathname === '/api/download-stream' && method === 'GET') {
    const targetUrl = reqUrl.searchParams.get('url');
    const videoIndices = reqUrl.searchParams.get('videoIndices') || '';
    const isSelectAll = reqUrl.searchParams.get('isSelectAll') || 'true';
    const quality = reqUrl.searchParams.get('quality') || 'best';
    const format = reqUrl.searchParams.get('format') || 'mp4';
    const subtitles = reqUrl.searchParams.get('subtitles') || 'false';
    const thumbnails = reqUrl.searchParams.get('thumbnails') || 'false';
    const downloadDir = reqUrl.searchParams.get('downloadDir') || '';

    if (!targetUrl) {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      return res.end('URL query param required');
    }

    // Determine target save directory
    let targetSaveDir = DOWNLOADS_DIR;
    if (downloadDir && downloadDir.trim().length > 0) {
      const customPath = path.normalize(downloadDir.trim());
      try {
        if (!fs.existsSync(customPath)) {
          fs.mkdirSync(customPath, { recursive: true });
        }
        targetSaveDir = customPath;
      } catch (err) {
        console.warn('[Download] Custom folder creation failed, fallback to ./downloads:', err.message);
      }
    }

    // Set Server-Sent Events headers
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    });

    const sendSSE = (event, data) => {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };

    const ytdlp = getYtDlpPath();
    const ffmpegPath = getFfmpegPath();

    sendSSE('log', { message: `Initializing download engine... Target folder: ${targetSaveDir}` });

    const args = [
      '--newline',
      '--progress',
      '--no-warnings',
      '--no-keep-video',
      '--extractor-retries', '10',
      '--retry-sleep', 'extractor:5',
      '--retries', '10',
      '--fragment-retries', '10',
      '--file-access-retries', '10',
      '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      '--sleep-interval', '1',
      '--max-sleep-interval', '5',
      '--concurrent-fragments', '1'
    ];

    // Try to use cookies from installed browsers to bypass 403 Forbidden
    // We try common browsers in order of popularity. yt-dlp will silently
    // ignore --cookies-from-browser if the browser isn't installed.
    const browsers = ['chrome', 'edge', 'firefox', 'brave', 'opera', 'vivaldi'];
    let cookieBrowserFound = false;
    for (const browser of browsers) {
      try {
        // Quick check: just see if yt-dlp can read cookies from this browser without error
        require('child_process').execSync(
          `"${ytdlp}" --cookies-from-browser ${browser} --dump-single-json --flat-playlist --skip-download "https://www.youtube.com/watch?v=jNQXAC9IVRw"`,
          { timeout: 20000, encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }
        );
        args.push('--cookies-from-browser', browser);
        cookieBrowserFound = true;
        console.log(`[Download] Using cookies from browser: ${browser}`);
        sendSSE('log', { message: `✅ Using ${browser} cookies for YouTube authentication...` });
        break;
      } catch (e) {
        // This browser's cookies didn't work or browser not installed, try next
        console.log(`[Download] Cookie attempt for ${browser} failed: ${(e.message || '').substring(0, 80)}`);
      }
    }

    if (!cookieBrowserFound) {
      console.log('[Download] No browser cookies available, proceeding without authentication');
      sendSSE('log', { message: '⚠️ No browser cookies found. If downloads fail with 403, open YouTube in Chrome/Edge and sign in first, then retry.' });
    }

    if (ffmpegPath) {
      const ffmpegDir = fs.existsSync(ffmpegPath) ? path.dirname(ffmpegPath) : ffmpegPath;
      args.push('--ffmpeg-location', ffmpegDir);
    }

    // Quality selection logic
    if (quality === 'mp3' || quality === 'm4a' || quality === 'wav') {
      args.push('-x');
      args.push('--audio-format', quality);
      args.push('--audio-quality', '0'); // Best audio bitrate
    } else {
      let formatFilter = 'bestvideo+bestaudio/best';
      if (quality === '2160p' || quality === '4k') {
        formatFilter = 'bestvideo[height<=2160]+bestaudio/best[height<=2160]/best';
      } else if (quality === '1080p') {
        formatFilter = 'bestvideo[height<=1080]+bestaudio/best[height<=1080]/best';
      } else if (quality === '720p') {
        formatFilter = 'bestvideo[height<=720]+bestaudio/best[height<=720]/best';
      } else if (quality === '480p') {
        formatFilter = 'bestvideo[height<=480]+bestaudio/best[height<=480]/best';
      } else if (quality === '360p') {
        formatFilter = 'bestvideo[height<=360]+bestaudio/best[height<=360]/best';
      }
      args.push('-f', formatFilter);
      args.push('--merge-output-format', format);
    }

    if (subtitles === 'true') {
      args.push('--write-subs', '--sub-format', 'srt/vtt', '--embed-subs');
    }
    if (thumbnails === 'true') {
      args.push('--write-thumbnail');
    }

    // If specific video indices were selected (and not ALL), use --playlist-items
    if (isSelectAll !== 'true' && videoIndices && videoIndices.trim().length > 0) {
      args.push('--playlist-items', videoIndices.trim());
    }

    const outputSubfolder = path.join(targetSaveDir, '%(playlist_title,single_video)s');
    const outputTemplate = path.join(outputSubfolder, '%(playlist_index,1)s - %(title)s.%(ext)s');
    args.push('-o', outputTemplate);
    args.push(targetUrl);

    console.log('[Download] Spawning yt-dlp with args:', args.join(' '));
    sendSSE('start', { message: 'Download session initiated...' });

    const proc = spawn(ytdlp, args);
    let currentVideo = '';

    proc.stdout.on('data', (data) => {
      const line = data.toString().trim();

      const itemMatch = line.match(/\[download\]\s+Downloading item\s+(\d+)\s+of\s+(\d+)/i);
      if (itemMatch) {
        sendSSE('item-change', {
          currentIndex: parseInt(itemMatch[1]),
          totalItems: parseInt(itemMatch[2])
        });
      }

      const destMatch = line.match(/\[download\]\s+Destination:\s+(.+)/i);
      if (destMatch) {
        currentVideo = path.basename(destMatch[1]);
        sendSSE('video-title', { title: currentVideo });
      }

      const progressMatch = line.match(/\[download\]\s+([\d\.]+)%\s+of\s+~?([\d\.]+\s*\w+)\s+at\s+([\d\.]+\s*\w+\/s)\s+ETA\s+([\d:]+)/i);
      if (progressMatch) {
        sendSSE('progress', {
          percent: parseFloat(progressMatch[1]),
          totalSize: progressMatch[2],
          speed: progressMatch[3],
          eta: progressMatch[4],
          currentVideo
        });
      } else {
        if (line.startsWith('[download]') || line.startsWith('[ffmpeg]') || line.startsWith('[ExtractAudio]')) {
          sendSSE('log', { message: line });
        }
      }
    });

    let errorCount = 0;
    let totalItems = 0;
    let successCount = 0;

    proc.stderr.on('data', (data) => {
      const errLine = data.toString().trim();
      if (errLine && !errLine.includes('WARNING:')) {
        sendSSE('log', { message: `Notice: ${errLine}` });
        if (errLine.includes('HTTP Error 403') || errLine.includes('Forbidden')) {
          errorCount++;
        }
      }
    });

    proc.on('close', (code) => {
      console.log(`[Download] Process finished with exit code ${code}, errors: ${errorCount}`);
      if (code === 0 && errorCount === 0) {
        sendSSE('complete', { message: 'All requested downloads completed successfully!' });
      } else if (errorCount > 0) {
        sendSSE('error', { 
          message: `Download had ${errorCount} error(s). YouTube blocked ${errorCount} video(s) with 403 Forbidden. Try: (1) Open YouTube in your browser and sign in, (2) Click "Update yt-dlp" button, (3) Try again.`,
          errorType: '403_FORBIDDEN',
          errorCount 
        });
      } else {
        sendSSE('error', { message: `Download ended with status code ${code}` });
      }
      res.end();
    });

    req.on('close', () => {
      console.log('[Download] SSE client disconnected.');
      if (proc && !proc.killed) {
        proc.kill();
      }
    });
    return;
  }

  // -------------------------------------------------------------
  // 3. API: Force Update yt-dlp (POST /api/update-ytdlp)
  // -------------------------------------------------------------
  if (pathname === '/api/update-ytdlp' && method === 'POST') {
    try {
      console.log('[API] Force updating yt-dlp binary...');
      const success = await updateYtDlp();
      
      // Get version after update
      let version = 'unknown';
      try {
        version = require('child_process').execSync(
          `"${getYtDlpPath()}" --version`, 
          { timeout: 10000, encoding: 'utf8' }
        ).trim();
      } catch (e) {}

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        success, 
        message: success ? `yt-dlp updated successfully to version ${version}` : 'Update failed. Please try again.',
        version 
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // -------------------------------------------------------------
  // 4. API: List Completed Downloads (GET /api/files)
  // -------------------------------------------------------------
  if (pathname === '/api/files' && method === 'GET') {
    try {
      const getFilesRecursively = (dir) => {
        let results = [];
        if (!fs.existsSync(dir)) return results;
        const list = fs.readdirSync(dir);
        list.forEach((file) => {
          const filePath = path.join(dir, file);
          const stat = fs.statSync(filePath);
          if (stat && stat.isDirectory()) {
            results = results.concat(getFilesRecursively(filePath));
          } else {
            const relativePath = path.relative(DOWNLOADS_DIR, filePath);
            results.push({
              name: file,
              path: relativePath.replace(/\\/g, '/'),
              size: formatBytes(stat.size),
              downloadUrl: `/downloads/${relativePath.replace(/\\/g, '/')}`
            });
          }
        });
        return results;
      };

      const files = getFilesRecursively(DOWNLOADS_DIR);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ files }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Failed to list downloads folder' }));
    }
    return;
  }

  // -------------------------------------------------------------
  // 4. API: Local Drives (GET /api/drives)
  // -------------------------------------------------------------
  if (pathname === '/api/drives' && method === 'GET') {
    const drives = [];
    for (let i = 65; i <= 90; i++) {
      const drive = String.fromCharCode(i) + ':/';
      try {
        const stat = fs.statSync(drive);
        if (stat.isDirectory()) {
          drives.push(drive);
        }
      } catch (e) {}
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ drives }));
  }

  // -------------------------------------------------------------
  // 5. API: Local Folders (GET /api/folders?path=...)
  // -------------------------------------------------------------
  if (pathname === '/api/folders' && method === 'GET') {
    const targetPath = reqUrl.searchParams.get('path') || 'C:/';
    try {
      if (!fs.existsSync(targetPath)) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Path not found' }));
      }
      
      const items = fs.readdirSync(targetPath);
      const folders = [];
      items.forEach(item => {
        try {
          const fullPath = path.join(targetPath, item);
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory() && !item.startsWith('$') && item !== 'System Volume Information') {
            folders.push({ name: item, path: fullPath });
          }
        } catch (err) {
          // Ignore permission errors
        }
      });
      
      // Sort alphabetically
      folders.sort((a, b) => a.name.localeCompare(b.name));
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ currentPath: targetPath, folders }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Failed to read directory' }));
    }
  }

  // -------------------------------------------------------------
  // 6. Static File Server (/ and /downloads/*)
  // -------------------------------------------------------------
  let reqPath = pathname;
  if (reqPath === '/') {
    reqPath = '/index.html';
  }

  let filePath = '';
  if (reqPath.startsWith('/downloads/')) {
    filePath = path.join(DOWNLOADS_DIR, reqPath.replace('/downloads/', ''));
  } else {
    filePath = path.join(PUBLIC_DIR, reqPath);
  }

  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('404 Not Found');
    }

    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stats.size
    });

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

function formatDuration(seconds) {
  if (!seconds || isNaN(seconds)) return 'N/A';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  if (hrs > 0) {
    return `${hrs}:${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

async function startServer() {
  try {
    console.log('[Server] Ensuring yt-dlp binary presence...');
    await ensureYtDlp();

    server.listen(PORT, () => {
      console.log(`=======================================================`);
      console.log(`🚀 YouTube Playlist Downloader Server is Ready!`);
      console.log(`🌐 Open in your browser: http://localhost:${PORT}`);
      console.log(`=======================================================`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
  }
}

startServer();
