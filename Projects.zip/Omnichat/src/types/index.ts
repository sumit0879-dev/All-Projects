export interface FileAttachment {
  id: string;
  name: string;
  size: number;
  type: string;
  content?: string;
  dataUrl?: string;
}

export interface AppSettings {
  baseUrl: string;
  apiKey: string;
  hasApiKey?: boolean;
  maskedApiKey?: string;
  defaultModel: string;
  theme: 'dark' | 'light' | 'system';
  temperature: number;
  maxTokens: number;
  streaming: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  model: string;
  systemPrompt?: string;
  temperature: number;
  maxTokens: number;
  isPinned?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  model?: string;
  attachments?: FileAttachment[];
  createdAt: number;
  isStreaming?: boolean;
  error?: boolean;
}

export interface ModelOption {
  id: string;
  name: string;
  provider?: string;
  ownedBy?: string;
}

export type ConnectionStatus = 'connected' | 'disconnected' | 'checking';

export interface DiagnosticResult {
  baseUrl: string;
  serverReachable: boolean;
  authValid: boolean;
  modelsWorking: boolean;
  modelsCount: number;
  selectedModel: string;
  latencyMs: number;
  message: string;
  details?: string;
}
