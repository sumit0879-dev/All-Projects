import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppSettings, ConnectionStatus, ModelOption } from '../types';
import * as api from '../services/api';

interface SettingsContextType {
  settings: AppSettings;
  connectionStatus: ConnectionStatus;
  statusMessage: string;
  models: ModelOption[];
  isFetchingModels: boolean;
  isSettingsOpen: boolean;
  activeSettingsTab: string;
  openSettings: (tab?: string) => void;
  closeSettings: () => void;
  updateSettings: (newSettings: Partial<AppSettings>) => Promise<AppSettings>;
  resetSettings: () => Promise<AppSettings>;
  checkConnection: (baseUrl?: string, apiKey?: string) => Promise<boolean>;
  loadModels: (baseUrl?: string, apiKey?: string) => Promise<ModelOption[]>;
  setTheme: (theme: 'dark' | 'light' | 'system') => void;
}

const DEFAULT_SETTINGS: AppSettings = {
  baseUrl: 'http://localhost:20128/v1',
  apiKey: '',
  defaultModel: 'auto',
  theme: 'dark',
  temperature: 0.7,
  maxTokens: 4096,
  streaming: true
};

const SettingsContext = createContext<SettingsContextType | null>(null);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('checking');
  const [statusMessage, setStatusMessage] = useState<string>('Checking OmniRoute server status...');
  const [models, setModels] = useState<ModelOption[]>([
    { id: 'auto', name: 'Auto (OmniRoute Router)', provider: 'omniroute' }
  ]);
  const [isFetchingModels, setIsFetchingModels] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [activeSettingsTab, setActiveSettingsTab] = useState<string>('connection');

  // Apply Theme to DOM
  const applyTheme = (theme: 'dark' | 'light' | 'system') => {
    const root = document.documentElement;
    if (theme === 'system') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    } else if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  };

  // Initial Boot: Load settings & check connection
  useEffect(() => {
    const init = async () => {
      try {
        const loaded = await api.fetchSettings();
        setSettings(loaded);
        applyTheme(loaded.theme);
        
        // Auto check connection on load
        await checkConnection(loaded.baseUrl, loaded.apiKey);
        await loadModels(loaded.baseUrl, loaded.apiKey);
      } catch (err: any) {
        console.error('Failed to load initial settings:', err);
        setConnectionStatus('disconnected');
        setStatusMessage('Backend server unreachable. Make sure Express proxy is running.');
      }
    };
    init();
  }, []);

  const openSettings = (tab = 'connection') => {
    setActiveSettingsTab(tab);
    setIsSettingsOpen(true);
  };

  const closeSettings = () => {
    setIsSettingsOpen(false);
  };

  const setTheme = (theme: 'dark' | 'light' | 'system') => {
    applyTheme(theme);
    updateSettings({ theme });
  };

  const updateSettings = async (newSettings: Partial<AppSettings>) => {
    try {
      const updated = await api.saveSettings(newSettings);
      setSettings(updated);
      if (newSettings.theme) {
        applyTheme(newSettings.theme);
      }
      return updated;
    } catch (err: any) {
      console.error('Failed to update settings:', err);
      throw err;
    }
  };

  const resetSettings = async () => {
    try {
      const defaultSet = await api.resetSettings();
      setSettings(defaultSet);
      applyTheme(defaultSet.theme);
      await checkConnection(defaultSet.baseUrl, defaultSet.apiKey);
      await loadModels(defaultSet.baseUrl, defaultSet.apiKey);
      return defaultSet;
    } catch (err: any) {
      console.error('Failed to reset settings:', err);
      throw err;
    }
  };

  const checkConnection = async (baseUrl?: string, apiKey?: string): Promise<boolean> => {
    setConnectionStatus('checking');
    setStatusMessage('Testing connection to OmniRoute...');
    try {
      const res = await api.testOmniRouteConnection(baseUrl || settings.baseUrl, apiKey !== undefined ? apiKey : settings.apiKey);
      if (res.success) {
        setConnectionStatus('connected');
        setStatusMessage(res.message || 'Connected to OmniRoute');
        return true;
      } else {
        setConnectionStatus('disconnected');
        setStatusMessage(res.message || 'Disconnected from OmniRoute');
        return false;
      }
    } catch (err: any) {
      setConnectionStatus('disconnected');
      setStatusMessage(`OmniRoute error: ${err.message}`);
      return false;
    }
  };

  const loadModels = async (baseUrl?: string, apiKey?: string): Promise<ModelOption[]> => {
    setIsFetchingModels(true);
    try {
      const fetched = await api.fetchOmniRouteModels(baseUrl || settings.baseUrl, apiKey !== undefined ? apiKey : settings.apiKey);
      
      // Ensure "auto" is always the first model
      let finalModels = fetched;
      if (!finalModels.some(m => m.id === 'auto')) {
        finalModels = [
          { id: 'auto', name: 'Auto (OmniRoute Router)', provider: 'omniroute' },
          ...fetched
        ];
      }

      setModels(finalModels);
      return finalModels;
    } catch (err: any) {
      console.warn('Failed to load models list:', err);
      // Fallback model list
      const fallback: ModelOption[] = [
        { id: 'auto', name: 'Auto (OmniRoute Router)', provider: 'omniroute' }
      ];
      setModels(fallback);
      return fallback;
    } finally {
      setIsFetchingModels(false);
    }
  };

  return (
    <SettingsContext.Provider
      value={{
        settings,
        connectionStatus,
        statusMessage,
        models,
        isFetchingModels,
        isSettingsOpen,
        activeSettingsTab,
        openSettings,
        closeSettings,
        updateSettings,
        resetSettings,
        checkConnection,
        loadModels,
        setTheme
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) throw new Error('useSettings must be used within SettingsProvider');
  return context;
};
