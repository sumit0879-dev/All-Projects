import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { Conversation, Message, FileAttachment } from '../types';
import { useSettings } from './SettingsContext';
import * as api from '../services/api';
import { readSSEStream } from '../services/stream';

interface ChatContextType {
  conversations: Conversation[];
  activeConversationId: string | null;
  activeConversation: Conversation | null;
  messages: Message[];
  selectedModel: string;
  setSelectedModel: (model: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isStreaming: boolean;
  isLoadingMessages: boolean;
  activeError: string | null;
  setActiveError: (err: string | null) => void;
  createNewChat: (model?: string) => Promise<string>;
  selectConversation: (id: string) => Promise<void>;
  deleteConversation: (id: string) => Promise<void>;
  renameConversation: (id: string, newTitle: string) => Promise<void>;
  togglePinConversation: (id: string) => Promise<void>;
  updateSystemPrompt: (id: string, systemPrompt: string) => Promise<void>;
  sendMessage: (content: string, attachments?: FileAttachment[]) => Promise<void>;
  stopGeneration: () => void;
  regenerateLastResponse: () => Promise<void>;
  editUserMessage: (messageId: string, newContent: string) => Promise<void>;
}

const ChatContext = createContext<ChatContextType | null>(null);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { settings } = useSettings();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('auto');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [isLoadingMessages, setIsLoadingMessages] = useState<boolean>(false);
  const [activeError, setActiveError] = useState<string | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);

  const activeConversation = conversations.find(c => c.id === activeConversationId) || null;

  useEffect(() => {
    if (activeConversation) {
      setSelectedModel(activeConversation.model || 'auto');
    } else {
      setSelectedModel(settings.defaultModel || 'auto');
    }
  }, [activeConversationId, conversations, settings.defaultModel]);

  useEffect(() => {
    loadConversations();
  }, []);

  const loadConversations = async () => {
    try {
      const list = await api.fetchConversations();
      setConversations(list);
      if (list.length > 0 && !activeConversationId) {
        await selectConversation(list[0].id);
      }
    } catch (err: any) {
      console.error('Failed to load conversations:', err);
    }
  };

  const selectConversation = async (id: string) => {
    setActiveConversationId(id);
    setIsLoadingMessages(true);
    setActiveError(null);
    try {
      const details = await api.fetchConversationDetails(id);
      setMessages(details.messages || []);
      if (details.conversation.model) {
        setSelectedModel(details.conversation.model);
      }
    } catch (err: any) {
      console.error('Failed to load conversation details:', err);
      setActiveError('Failed to load message history.');
    } finally {
      setIsLoadingMessages(false);
    }
  };

  const createNewChat = async (modelOverride?: string): Promise<string> => {
    setActiveError(null);
    const modelToUse = modelOverride || selectedModel || settings.defaultModel || 'auto';
    try {
      const newConv = await api.createConversation('New Chat', modelToUse);
      setConversations(prev => [newConv, ...prev]);
      setActiveConversationId(newConv.id);
      setMessages([]);
      setSelectedModel(modelToUse);
      return newConv.id;
    } catch (err: any) {
      console.error('Failed to create new chat:', err);
      setActiveError('Failed to create a new chat.');
      throw err;
    }
  };

  const updateSelectedModel = async (model: string) => {
    setSelectedModel(model);
    if (activeConversationId) {
      try {
        const updated = await api.updateConversation(activeConversationId, { model });
        setConversations(prev => prev.map(c => c.id === activeConversationId ? { ...c, model: updated.model } : c));
      } catch (err) {
        console.error('Failed to save selected model to conversation:', err);
      }
    }
  };

  const togglePinConversation = async (id: string) => {
    const target = conversations.find(c => c.id === id);
    if (!target) return;
    const newPinState = !target.isPinned;
    try {
      const updated = await api.updateConversation(id, { isPinned: newPinState });
      setConversations(prev => {
        const list = prev.map(c => c.id === id ? { ...c, isPinned: updated.isPinned } : c);
        return list.sort((a, b) => {
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
          return b.updatedAt - a.updatedAt;
        });
      });
    } catch (err) {
      console.error('Failed to pin/unpin conversation:', err);
    }
  };

  const updateSystemPrompt = async (id: string, systemPrompt: string) => {
    try {
      const updated = await api.updateConversation(id, { systemPrompt });
      setConversations(prev => prev.map(c => c.id === id ? { ...c, systemPrompt: updated.systemPrompt } : c));
    } catch (err) {
      console.error('Failed to save system prompt:', err);
    }
  };

  const deleteConversation = async (id: string) => {
    try {
      await api.deleteConversation(id);
      const remaining = conversations.filter(c => c.id !== id);
      setConversations(remaining);
      if (activeConversationId === id) {
        if (remaining.length > 0) {
          await selectConversation(remaining[0].id);
        } else {
          setActiveConversationId(null);
          setMessages([]);
        }
      }
    } catch (err: any) {
      console.error('Failed to delete conversation:', err);
      setActiveError('Failed to delete conversation.');
    }
  };

  const renameConversation = async (id: string, newTitle: string) => {
    try {
      const updated = await api.updateConversation(id, { title: newTitle });
      setConversations(prev => prev.map(c => c.id === id ? { ...c, title: updated.title } : c));
    } catch (err: any) {
      console.error('Failed to rename conversation:', err);
      setActiveError('Failed to rename conversation.');
    }
  };

  const stopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
  };

  const sendMessage = async (content: string, attachments?: FileAttachment[]) => {
    if ((!content.trim() && (!attachments || attachments.length === 0)) || isStreaming) return;
    setActiveError(null);

    let targetConvId = activeConversationId;
    if (!targetConvId) {
      targetConvId = await createNewChat(selectedModel);
    }

    // Process attachments into prompt text context
    let fullPromptContent = content;
    if (attachments && attachments.length > 0) {
      const fileTexts = attachments.map(a => {
        if (a.content) {
          return `\n\n--- ATTACHED FILE: ${a.name} ---\n${a.content}\n--- END ATTACHED FILE ---`;
        }
        if (a.dataUrl) {
          return `\n\n[Attached Image: ${a.name}]`;
        }
        return '';
      }).join('');
      fullPromptContent = content + fileTexts;
    }

    // Save user message to database & update UI instantly
    const userMsgId = 'msg-' + Date.now() + '-u';
    const tempUserMsg: Message = {
      id: userMsgId,
      conversationId: targetConvId,
      role: 'user',
      content: content || (attachments ? `[Attached ${attachments.length} file(s)]` : ''),
      attachments,
      createdAt: Date.now()
    };

    setMessages(prev => [...prev, tempUserMsg]);

    try {
      await api.addMessage(targetConvId, 'user', tempUserMsg.content, selectedModel);
      loadConversations();
    } catch (e) {
      console.warn('Failed to save user message:', e);
    }

    // Create assistant message stream target
    const assistantMsgId = 'msg-' + Date.now() + '-a';
    const tempAssistantMsg: Message = {
      id: assistantMsgId,
      conversationId: targetConvId,
      role: 'assistant',
      content: '',
      model: selectedModel,
      createdAt: Date.now() + 1,
      isStreaming: true
    };

    setMessages(prev => [...prev, tempAssistantMsg]);
    setIsStreaming(true);

    abortControllerRef.current = new AbortController();

    try {
      // Prepend System Prompt if specified
      const currentConv = conversations.find(c => c.id === targetConvId);
      const messagesPayload: Message[] = [];

      if (currentConv?.systemPrompt) {
        messagesPayload.push({
          id: 'sys-' + Date.now(),
          conversationId: targetConvId,
          role: 'system',
          content: currentConv.systemPrompt,
          createdAt: Date.now() - 100
        });
      }

      // Append prior messages + new message with attached text
      const previousMessages = messages.map(m => ({
        id: m.id,
        conversationId: targetConvId!,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt
      }));

      messagesPayload.push(...previousMessages);
      messagesPayload.push({
        ...tempUserMsg,
        content: fullPromptContent
      });

      const response = await api.sendChatRequest(
        targetConvId,
        messagesPayload,
        selectedModel,
        settings.temperature,
        settings.maxTokens,
        abortControllerRef.current.signal
      );

      if (!response.ok) {
        const errJson = await response.json().catch(() => null);
        throw new Error(errJson?.error || `OmniRoute returned HTTP status ${response.status}`);
      }

      await readSSEStream(
        response,
        (token) => {
          setMessages(prev =>
            prev.map(msg =>
              msg.id === assistantMsgId
                ? { ...msg, content: msg.content + token }
                : msg
            )
          );
        },
        (streamErr) => {
          setActiveError(`OmniRoute error: ${streamErr}`);
          setMessages(prev =>
            prev.map(msg =>
              msg.id === assistantMsgId
                ? { ...msg, isStreaming: false, error: true }
                : msg
            )
          );
        },
        abortControllerRef.current.signal
      );
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Chat generation error:', err);
        setActiveError(err.message || 'Failed to receive AI response from OmniRoute');
        setMessages(prev =>
          prev.map(msg =>
            msg.id === assistantMsgId
              ? { ...msg, content: msg.content || '⚠️ Connection error with OmniRoute server.', isStreaming: false, error: true }
              : msg
          )
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
      setMessages(prev =>
        prev.map(msg => msg.id === assistantMsgId ? { ...msg, isStreaming: false } : msg)
      );
    }
  };

  const regenerateLastResponse = async () => {
    if (!activeConversationId || isStreaming || messages.length < 2) return;

    const lastMsg = messages[messages.length - 1];
    if (lastMsg.role === 'assistant') {
      const truncated = messages.slice(0, messages.length - 1);
      const lastUserMsg = truncated[truncated.length - 1];

      if (lastUserMsg && lastUserMsg.role === 'user') {
        setMessages(truncated);
        await api.truncateMessagesFrom(activeConversationId, lastMsg.id).catch(() => {});
        
        const assistantMsgId = 'msg-' + Date.now() + '-regen';
        const tempAssistantMsg: Message = {
          id: assistantMsgId,
          conversationId: activeConversationId,
          role: 'assistant',
          content: '',
          model: selectedModel,
          createdAt: Date.now(),
          isStreaming: true
        };

        setMessages([...truncated, tempAssistantMsg]);
        setIsStreaming(true);
        abortControllerRef.current = new AbortController();

        try {
          const response = await api.sendChatRequest(
            activeConversationId,
            truncated,
            selectedModel,
            settings.temperature,
            settings.maxTokens,
            abortControllerRef.current.signal
          );

          if (!response.ok) {
            const errJson = await response.json().catch(() => null);
            throw new Error(errJson?.error || `OmniRoute Error (${response.status})`);
          }

          await readSSEStream(
            response,
            (token) => {
              setMessages(prev =>
                prev.map(msg =>
                  msg.id === assistantMsgId
                    ? { ...msg, content: msg.content + token }
                    : msg
                )
              );
            },
            (err) => setActiveError(`Regeneration error: ${err}`),
            abortControllerRef.current.signal
          );
        } catch (e: any) {
          if (e.name !== 'AbortError') {
            setActiveError(e.message || 'Regeneration failed');
          }
        } finally {
          setIsStreaming(false);
          abortControllerRef.current = null;
          setMessages(prev =>
            prev.map(msg => msg.id === assistantMsgId ? { ...msg, isStreaming: false } : msg)
          );
        }
      }
    }
  };

  const editUserMessage = async (messageId: string, newContent: string) => {
    if (!activeConversationId || isStreaming) return;
    
    const msgIndex = messages.findIndex(m => m.id === messageId);
    if (msgIndex === -1) return;

    await api.truncateMessagesFrom(activeConversationId, messageId).catch(() => {});

    const truncated = messages.slice(0, msgIndex);
    setMessages(truncated);
    await sendMessage(newContent);
  };

  return (
    <ChatContext.Provider
      value={{
        conversations,
        activeConversationId,
        activeConversation,
        messages,
        selectedModel,
        setSelectedModel: updateSelectedModel,
        searchQuery,
        setSearchQuery,
        isStreaming,
        isLoadingMessages,
        activeError,
        setActiveError,
        createNewChat,
        selectConversation,
        deleteConversation,
        renameConversation,
        togglePinConversation,
        updateSystemPrompt,
        sendMessage,
        stopGeneration,
        regenerateLastResponse,
        editUserMessage
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) throw new Error('useChat must be used within ChatProvider');
  return context;
};
