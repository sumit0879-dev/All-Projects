import React, { useState, useEffect } from 'react';
import { SettingsProvider } from './context/SettingsContext';
import { ChatProvider } from './context/ChatContext';
import { Sidebar } from './components/sidebar/Sidebar';
import { ChatArea } from './components/chat/ChatArea';
import { SettingsModal } from './components/settings/SettingsModal';

const Shell: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[var(--surface-0)] text-[var(--text-1)]">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? 'w-[280px] min-w-[280px]' : 'w-0 min-w-0'
        } transition-all duration-300 ease-in-out overflow-hidden border-r border-[var(--surface-3)]`}
      >
        <Sidebar
          onCollapse={() => setSidebarOpen(false)}
          darkMode={darkMode}
          onToggleDark={() => setDarkMode(!darkMode)}
        />
      </div>

      {/* Main Chat Area */}
      <ChatArea
        sidebarOpen={sidebarOpen}
        onOpenSidebar={() => setSidebarOpen(true)}
      />

      <SettingsModal />
    </div>
  );
};

const App: React.FC = () => (
  <SettingsProvider>
    <ChatProvider>
      <Shell />
    </ChatProvider>
  </SettingsProvider>
);

export default App;
