/**
 * Helper to process Server-Sent Event streams from backend proxy
 */
export async function readSSEStream(
  response: Response,
  onToken: (token: string) => void,
  onError: (error: string) => void,
  signal?: AbortSignal
): Promise<string> {
  if (!response.body) {
    throw new Error('Response body is null');
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let accumulatedText = '';
  let buffer = '';

  try {
    while (true) {
      if (signal?.aborted) {
        reader.cancel();
        break;
      }

      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || ''; // Keep partial line in buffer

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(':')) continue; // Ignore comments/pings

        if (trimmed === 'data: [DONE]') {
          return accumulatedText;
        }

        if (trimmed.startsWith('data: ')) {
          const jsonStr = trimmed.slice(6);
          try {
            const parsed = JSON.parse(jsonStr);
            if (parsed.error) {
              onError(typeof parsed.error === 'string' ? parsed.error : JSON.stringify(parsed.error));
              return accumulatedText;
            }

            const token = parsed.choices?.[0]?.delta?.content;
            if (token) {
              accumulatedText += token;
              onToken(token);
            }
          } catch (e) {
            // Partial JSON snippet, skip
          }
        }
      }
    }
  } catch (err: any) {
    if (err.name !== 'AbortError') {
      onError(err.message || 'Stream processing error');
    }
  }

  return accumulatedText;
}
