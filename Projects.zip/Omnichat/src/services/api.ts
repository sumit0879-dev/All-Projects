import { AppSettings, Conversation, Message, ModelOption, DiagnosticResult } from '../types';

const API_BASE = '/api';

export async function fetchSettings(): Promise<AppSettings> {
  const res = await fetch(`${API_BASE}/settings`);
  if (!res.ok) throw new Error('Failed to fetch settings');
  const data = await res.json();
  return data.settings;
}

export async function saveSettings(settings: Partial<AppSettings>): Promise<AppSettings> {
  const res = await fetch(`${API_BASE}/settings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings)
  });
  if (!res.ok) throw new Error('Failed to save settings');
  const data = await res.json();
  return data.settings;
}

export async function resetSettings(): Promise<AppSettings> {
  const res = await fetch(`${API_BASE}/settings/reset`, {
    method: 'POST'
  });
  if (!res.ok) throw new Error('Failed to reset settings');
  const data = await res.json();
  return data.settings;
}

export async function testOmniRouteConnection(overrideBaseUrl?: string, overrideApiKey?: string) {
  const res = await fetch(`${API_BASE}/omniroute/test`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ baseUrl: overrideBaseUrl, apiKey: overrideApiKey })
  });
  return await res.json();
}

export async function fetchOmniRouteModels(overrideBaseUrl?: string, overrideApiKey?: string): Promise<ModelOption[]> {
  const params = new URLSearchParams();
  if (overrideBaseUrl) params.append('baseUrl', overrideBaseUrl);
  if (overrideApiKey) params.append('apiKey', overrideApiKey);

  const url = `${API_BASE}/omniroute/models?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to fetch models from OmniRoute');
  }
  const data = await res.json();
  return data.models || [];
}

export async function fetchConversations(): Promise<Conversation[]> {
  const res = await fetch(`${API_BASE}/conversations`);
  if (!res.ok) throw new Error('Failed to load conversations');
  const data = await res.json();
  return data.conversations || [];
}

export async function fetchConversationDetails(id: string): Promise<{ conversation: Conversation; messages: Message[] }> {
  const res = await fetch(`${API_BASE}/conversations/${id}`);
  if (!res.ok) throw new Error('Conversation not found');
  return await res.json();
}

export async function createConversation(title = 'New Chat', model = 'auto'): Promise<Conversation> {
  const res = await fetch(`${API_BASE}/conversations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, model })
  });
  if (!res.ok) throw new Error('Failed to create conversation');
  const data = await res.json();
  return data.conversation;
}

export async function updateConversation(id: string, updates: Partial<Conversation>): Promise<Conversation> {
  const res = await fetch(`${API_BASE}/conversations/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  if (!res.ok) throw new Error('Failed to update conversation');
  const data = await res.json();
  return data.conversation;
}

export async function deleteConversation(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/conversations/${id}`, {
    method: 'DELETE'
  });
  if (!res.ok) throw new Error('Failed to delete conversation');
}

export async function addMessage(conversationId: string, role: 'user' | 'assistant', content: string, model?: string): Promise<Message> {
  const res = await fetch(`${API_BASE}/conversations/${conversationId}/messages`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ role, content, model })
  });
  if (!res.ok) throw new Error('Failed to save message');
  const data = await res.json();
  return data.message;
}

export async function truncateMessagesFrom(conversationId: string, fromMessageId: string): Promise<void> {
  const res = await fetch(`${API_BASE}/conversations/${conversationId}/messages/truncate`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fromMessageId })
  });
  if (!res.ok) throw new Error('Failed to truncate messages');
}

export async function sendChatRequest(
  conversationId: string,
  messages: Message[],
  model: string,
  temperature?: number,
  maxTokens?: number,
  signal?: AbortSignal
): Promise<Response> {
  return await fetch(`${API_BASE}/omniroute/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      conversationId,
      messages,
      model,
      temperature,
      maxTokens,
      stream: true
    }),
    signal
  });
}

export async function runDiagnostic(baseUrl?: string, apiKey?: string): Promise<DiagnosticResult> {
  const startTime = Date.now();
  const targetBaseUrl = (baseUrl || 'http://localhost:20128/v1').trim().replace(/\/+$/, '');

  try {
    const testRes = await testOmniRouteConnection(targetBaseUrl, apiKey);
    const latency = Date.now() - startTime;

    if (testRes.success) {
      return {
        baseUrl: targetBaseUrl,
        serverReachable: true,
        authValid: true,
        modelsWorking: true,
        modelsCount: testRes.modelsCount || 0,
        selectedModel: 'auto',
        latencyMs: testRes.latencyMs || latency,
        message: 'OmniRoute is fully connected and ready!'
      };
    }

    const isAuthErr = testRes.errorType === 'invalid_key';
    const isConnRefused = testRes.errorType === 'connection_refused';

    return {
      baseUrl: targetBaseUrl,
      serverReachable: !isConnRefused,
      authValid: !isAuthErr,
      modelsWorking: false,
      modelsCount: 0,
      selectedModel: 'auto',
      latencyMs: latency,
      message: testRes.message || 'Connection test failed',
      details: `Error code: ${testRes.errorType || 'unknown'}`
    };
  } catch (err: any) {
    return {
      baseUrl: targetBaseUrl,
      serverReachable: false,
      authValid: false,
      modelsWorking: false,
      modelsCount: 0,
      selectedModel: 'auto',
      latencyMs: Date.now() - startTime,
      message: `Diagnostic execution failed: ${err.message}`,
      details: 'Unable to reach backend local server'
    };
  }
}
