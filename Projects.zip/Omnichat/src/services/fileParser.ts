import { FileAttachment } from '../types';

export async function parseUploadedFile(file: File): Promise<FileAttachment> {
  const id = 'file-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
  const isImage = file.type.startsWith('image/');

  if (isImage) {
    const dataUrl = await readFileAsDataURL(file);
    return {
      id,
      name: file.name,
      size: file.size,
      type: file.type,
      dataUrl
    };
  }

  // Text / Code / Document file
  const content = await readFileAsText(file);
  return {
    id,
    name: file.name,
    size: file.size,
    type: file.type || 'text/plain',
    content
  };
}

function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read text file'));
    reader.readAsText(file);
  });
}

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}
