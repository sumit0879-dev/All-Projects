import React, { useState, useMemo } from 'react';
import { useChat } from '../../context/ChatContext';
import { useSettings } from '../../context/SettingsContext';
import {
  Plus, Search, Pin, Trash2, Pencil, Check, X,
  MessageSquare, Moon, Sun, PanelLeftClose, Settings, Wifi, WifiOff
} from 'lucide-react';

interface SidebarProps {
  onCollapse: () => void;
  darkMode: boolean;
  onToggleDark: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onCollapse, darkMode, onToggleDark }) => {
  const {
    conversations, activeConversationId, createNewChat,
    selectConversation, deleteConversation, renameConversation, togglePinConversation
  } = useChat();
  const { connectionStatus, openSettings } = useSettings();

  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    const list = q ? conversations.filter(c => c.title.toLowerCase().includes(q)) : conversations;
    return [...list].sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.updatedAt - a.updatedAt;
    });
  }, [conversations, search]);

  const startRename = (id: string, title: string) => {
    setEditingId(id);
    setEditTitle(title);
  };

  const confirmRename = (id: string) => {
    if (editTitle.trim()) renameConversation(id, editTitle.trim());
    setEditingId(null);
  };

  return (
    <div className="flex flex-col h-full w-[280px] bg-[var(--surface-1)] select-none">
      {/* Header - Claude style: just name + collapse */}
      <div className="flex items-center justify-between px-4 h-14 flex-shrink-0">
        <span className="font-bold text-sm text-[var(--text-1)]">OmniChat</span>
        <div className="flex items-center gap-1">
          <button onClick={onCollapse} className="p-1.5 rounded-lg hover:bg-[var(--surface-2)] text-[var(--text-4)] transition-colors" title="Close sidebar">
            <PanelLeftClose className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* New Chat - Claude style */}
      <div className="px-3 pb-2">
        <button
          onClick={() => createNewChat()}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-[var(--surface-2)] text-sm text-[var(--text-2)] transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          New chat
        </button>
      </div>

      {/* Search - only show when there are conversations */}
      {conversations.length > 3 && (
        <div className="px-3 pb-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-4)]" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search chats…"
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg bg-[var(--surface-2)] text-[var(--text-1)] placeholder:text-[var(--text-4)] border border-transparent focus:border-[var(--text-4)] focus:outline-none transition-colors"
            />
          </div>
        </div>
      )}

      {/* Recents label */}
      {conversations.length > 0 && (
        <div className="px-4 pt-2 pb-1">
          <span className="text-[11px] font-medium text-[var(--text-4)]">Recents</span>
        </div>
      )}

      {/* Conversation list */}
      <div className="flex-1 overflow-y-auto px-2">
        {filtered.length === 0 && conversations.length > 0 && (
          <div className="text-center text-xs text-[var(--text-4)] py-6">No results</div>
        )}

        {filtered.map(conv => {
          const isActive = conv.id === activeConversationId;
          const isEditing = editingId === conv.id;

          return (
            <div
              key={conv.id}
              onClick={() => !isEditing && selectConversation(conv.id)}
              className={`group relative flex items-center gap-2 px-3 py-2 rounded-lg mb-0.5 cursor-pointer transition-colors text-sm ${
                isActive ? 'bg-[var(--surface-2)] text-[var(--text-1)]' : 'hover:bg-[var(--surface-2)] text-[var(--text-2)]'
              }`}
            >
              {isEditing ? (
                <div className="flex-1 flex items-center gap-1">
                  <input
                    value={editTitle}
                    onChange={e => setEditTitle(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && confirmRename(conv.id)}
                    autoFocus
                    className="flex-1 text-xs bg-[var(--surface-0)] px-2 py-1 rounded border border-[var(--brand)] text-[var(--text-1)] focus:outline-none"
                    onClick={e => e.stopPropagation()}
                  />
                  <button onClick={e => { e.stopPropagation(); confirmRename(conv.id); }} className="p-0.5 text-[var(--success)]"><Check className="w-3.5 h-3.5" /></button>
                  <button onClick={e => { e.stopPropagation(); setEditingId(null); }} className="p-0.5 text-[var(--danger)]"><X className="w-3.5 h-3.5" /></button>
                </div>
              ) : (
                <>
                  <span className="flex-1 text-xs truncate">{conv.title}</span>
                  {conv.isPinned && <Pin className="w-3 h-3 text-[var(--text-4)] flex-shrink-0" />}

                  {/* Hover actions */}
                  <div className="hidden group-hover:flex items-center gap-0.5 absolute right-2 bg-[var(--surface-2)] rounded-md">
                    <button onClick={e => { e.stopPropagation(); startRename(conv.id, conv.title); }} className="p-1 rounded text-[var(--text-4)] hover:text-[var(--text-2)]" title="Rename">
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button onClick={e => { e.stopPropagation(); togglePinConversation(conv.id); }} className="p-1 rounded text-[var(--text-4)] hover:text-[var(--text-2)]" title="Pin">
                      <Pin className="w-3 h-3" />
                    </button>
                    <button onClick={e => { e.stopPropagation(); deleteConversation(conv.id); }} className="p-1 rounded text-[var(--text-4)] hover:text-[var(--danger)]" title="Delete">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer - Claude style: profile area */}
      <div className="border-t border-[var(--surface-3)] px-3 py-2.5 flex items-center justify-between flex-shrink-0">
        <button
          onClick={() => openSettings('connection')}
          className="flex items-center gap-2 text-xs text-[var(--text-3)] hover:text-[var(--text-1)] transition-colors"
        >
          {connectionStatus === 'connected'
            ? <Wifi className="w-3.5 h-3.5 text-[var(--success)]" />
            : <WifiOff className="w-3.5 h-3.5 text-[var(--danger)]" />
          }
          <span>{connectionStatus === 'connected' ? 'Connected' : 'Offline'}</span>
        </button>

        <div className="flex items-center gap-1">
          <button onClick={onToggleDark} className="p-1.5 rounded-lg hover:bg-[var(--surface-2)] text-[var(--text-4)] transition-colors" title="Theme">
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <button onClick={() => openSettings('connection')} className="p-1.5 rounded-lg hover:bg-[var(--surface-2)] text-[var(--text-4)] transition-colors" title="Settings">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
