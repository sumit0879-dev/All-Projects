import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { Conversation, Message } from '../../types';
import { Download, FileText, Code, FileCode } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  conversation: Conversation | null;
  messages: Message[];
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  conversation,
  messages
}) => {
  const [exportFormat, setExportFormat] = useState<'markdown' | 'json' | 'text'>('markdown');

  if (!conversation) return null;

  const handleExport = () => {
    let content = '';
    let fileName = `${conversation.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}`;
    let mimeType = 'text/plain';

    if (exportFormat === 'markdown') {
      fileName += '.md';
      mimeType = 'text/markdown';
      content = `# ${conversation.title}\n\n*Exported from OmniChat on ${new Date().toLocaleString()}*\n*Model: ${conversation.model}*\n\n---\n\n`;
      messages.forEach((msg) => {
        const roleStr = msg.role === 'user' ? '👤 **You**' : '🤖 **OmniRoute Assistant**';
        content += `${roleStr}:\n\n${msg.content}\n\n---\n\n`;
      });
    } else if (exportFormat === 'json') {
      fileName += '.json';
      mimeType = 'application/json';
      content = JSON.stringify({ conversation, messages }, null, 2);
    } else {
      fileName += '.txt';
      messages.forEach((msg) => {
        const roleStr = msg.role === 'user' ? 'YOU' : 'ASSISTANT';
        content += `[${roleStr}]\n${msg.content}\n\n`;
      });
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Export Conversation" maxWidth="max-w-md">
      <div className="space-y-6">
        <p className="text-xs text-[var(--text-secondary)]">
          Download conversation history for <strong>"{conversation.title}"</strong>.
        </p>

        <div className="grid grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => setExportFormat('markdown')}
            className={`flex flex-col items-center justify-center p-4 rounded-xl border text-xs font-medium transition-all ${
              exportFormat === 'markdown'
                ? 'bg-[var(--accent-light)] border-[var(--accent)] text-[var(--accent)] font-semibold shadow-sm'
                : 'bg-[var(--bg-secondary)] border-[var(--border-color)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <FileCode className="w-5 h-5 mb-1.5" />
            <span>Markdown (.md)</span>
          </button>

          <button
            type="button"
            onClick={() => setExportFormat('json')}
            className={`flex flex-col items-center justify-center p-4 rounded-xl border text-xs font-medium transition-all ${
              exportFormat === 'json'
                ? 'bg-[var(--accent-light)] border-[var(--accent)] text-[var(--accent)] font-semibold shadow-sm'
                : 'bg-[var(--bg-secondary)] border-[var(--border-color)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <Code className="w-5 h-5 mb-1.5" />
            <span>JSON (.json)</span>
          </button>

          <button
            type="button"
            onClick={() => setExportFormat('text')}
            className={`flex flex-col items-center justify-center p-4 rounded-xl border text-xs font-medium transition-all ${
              exportFormat === 'text'
                ? 'bg-[var(--accent-light)] border-[var(--accent)] text-[var(--accent)] font-semibold shadow-sm'
                : 'bg-[var(--bg-secondary)] border-[var(--border-color)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <FileText className="w-5 h-5 mb-1.5" />
            <span>Plain Text (.txt)</span>
          </button>
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-[var(--border-color)]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium rounded-xl border border-[var(--border-color)] hover:bg-[var(--bg-tertiary)] text-[var(--text-secondary)] transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleExport}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] transition-all flex items-center gap-1.5 shadow-md shadow-indigo-500/20"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export File</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
