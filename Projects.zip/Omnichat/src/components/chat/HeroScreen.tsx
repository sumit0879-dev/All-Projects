import React from 'react';
import { useSettings } from '../../context/SettingsContext';
import { Sparkles } from 'lucide-react';

interface HeroScreenProps {
  onSend: (text: string) => void;
}

export const HeroScreen: React.FC<HeroScreenProps> = ({ onSend }) => {
  const { connectionStatus, openSettings } = useSettings();

  // Get time-based greeting
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 select-none">
      <div className="flex flex-col items-center text-center">
        {/* Sparkle icon + Greeting - Claude style */}
        <div className="flex items-center gap-3 mb-4">
          <Sparkles className="w-8 h-8 text-[var(--brand)] opacity-80" />
          <h1 className="text-[2.5rem] font-serif font-normal text-[var(--text-1)] tracking-tight leading-tight">
            {greeting}
          </h1>
        </div>

        {/* Connection status - subtle */}
        {connectionStatus === 'disconnected' && (
          <button
            onClick={() => openSettings('connection')}
            className="mt-6 text-xs text-red-500/80 hover:text-red-500 transition-colors"
          >
            OmniRoute is offline — click to configure
          </button>
        )}
      </div>
    </div>
  );
};
