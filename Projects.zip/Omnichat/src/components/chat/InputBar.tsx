import React, { useState, useRef, useEffect } from 'react';
import { FileAttachment } from '../../types';
import { parseUploadedFile } from '../../services/fileParser';
import { FileAttachmentPreview } from './FileAttachmentPreview';
import { ArrowUp, Square, Plus, PanelLeft } from 'lucide-react';

interface InputBarProps {
  onSend: (text: string, attachments?: FileAttachment[]) => void;
  onStop: () => void;
  isStreaming: boolean;
  disabled?: boolean;
  selectedModel?: string;
  onOpenSidebar?: () => void;
}

export const InputBar: React.FC<InputBarProps> = ({ onSend, onStop, isStreaming, disabled, selectedModel, onOpenSidebar }) => {
  const [text, setText] = useState('');
  const [files, setFiles] = useState<FileAttachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (taRef.current) {
      taRef.current.style.height = 'auto';
      taRef.current.style.height = Math.min(taRef.current.scrollHeight, 200) + 'px';
    }
  }, [text]);

  const submit = () => {
    if ((!text.trim() && files.length === 0) || disabled || isStreaming) return;
    onSend(text.trim(), files.length > 0 ? files : undefined);
    setText('');
    setFiles([]);
    if (taRef.current) taRef.current.style.height = 'auto';
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); }
  };

  const onFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const parsed = await Promise.all(Array.from(e.target.files).map(parseUploadedFile));
    setFiles(prev => [...prev, ...parsed]);
    if (fileRef.current) fileRef.current.value = '';
  };

  const onDrop = async (e: React.DragEvent) => {
    e.preventDefault(); setIsDragging(false);
    if (e.dataTransfer.files.length) {
      const parsed = await Promise.all(Array.from(e.dataTransfer.files).map(parseUploadedFile));
      setFiles(prev => [...prev, ...parsed]);
    }
  };

  const canSend = (text.trim() || files.length > 0) && !disabled;

  return (
    <div
      className="px-4 pb-5 pt-2 relative"
      onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={onDrop}
    >
      {isDragging && (
        <div className="absolute inset-0 z-50 bg-[var(--brand-dim)] border-2 border-dashed border-[var(--brand)] rounded-2xl flex items-center justify-center text-sm font-medium text-[var(--brand)]">
          Drop files here
        </div>
      )}

      <div className="max-w-[760px] mx-auto">
        {/* Attachment previews */}
        {files.length > 0 && (
          <div className="mb-2">
            <FileAttachmentPreview attachments={files} onRemove={id => setFiles(f => f.filter(a => a.id !== id))} />
          </div>
        )}

        {/* Claude-style input card */}
        <div className="rounded-[24px] border border-[var(--surface-3)] bg-[var(--surface-1)] focus-within:border-[var(--text-4)] transition-colors shadow-sm overflow-hidden">
          {/* Textarea */}
          <textarea
            ref={taRef}
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={onKey}
            placeholder="How can I help you today?"
            disabled={disabled}
            rows={1}
            className="w-full px-5 pt-4 pb-2 text-sm bg-transparent text-[var(--text-1)] placeholder:text-[var(--text-4)] focus:outline-none resize-none min-h-[44px] max-h-[200px]"
          />

          {/* Bottom toolbar inside card */}
          <div className="flex items-center justify-between px-3 pb-3">
            <div className="flex items-center gap-1">
              {/* Sidebar toggle (when collapsed) */}
              {onOpenSidebar && (
                <button onClick={onOpenSidebar} className="p-2 rounded-xl text-[var(--text-4)] hover:text-[var(--text-2)] hover:bg-[var(--surface-2)] transition-colors" title="Open sidebar">
                  <PanelLeft className="w-4 h-4" />
                </button>
              )}

              {/* Attach button */}
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="p-2 rounded-xl text-[var(--text-4)] hover:text-[var(--text-2)] hover:bg-[var(--surface-2)] transition-colors"
                title="Attach file"
              >
                <Plus className="w-4 h-4" />
              </button>
              <input ref={fileRef} type="file" multiple onChange={onFileChange} className="hidden" />
            </div>

            <div className="flex items-center gap-2">
              {/* Model indicator */}
              <span className="text-[11px] text-[var(--text-4)] font-medium">
                {selectedModel || 'auto'}
              </span>

              {/* Send / Stop */}
              {isStreaming ? (
                <button
                  type="button"
                  onClick={onStop}
                  className="p-2 rounded-full bg-[var(--text-1)] text-[var(--surface-0)] hover:opacity-80 transition-opacity"
                  title="Stop"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={submit}
                  disabled={!canSend}
                  className={`p-2 rounded-full transition-all ${
                    canSend
                      ? 'bg-[var(--text-1)] text-[var(--surface-0)] hover:opacity-80 cursor-pointer'
                      : 'bg-[var(--surface-3)] text-[var(--text-4)] cursor-not-allowed'
                  }`}
                  title="Send"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
