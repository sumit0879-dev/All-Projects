import React from 'react';
import { FileAttachment } from '../../types';
import { FileText, Image, Code2, File, X } from 'lucide-react';

interface Props {
  attachments: FileAttachment[];
  readOnly?: boolean;
  onRemove?: (id: string) => void;
}

const iconFor = (type: string) => {
  if (type.startsWith('image')) return <Image className="w-4 h-4 text-pink-500" />;
  if (type.includes('json') || type.includes('javascript') || type.includes('typescript') || type.includes('python'))
    return <Code2 className="w-4 h-4 text-amber-500" />;
  if (type.includes('text') || type.includes('pdf') || type.includes('markdown'))
    return <FileText className="w-4 h-4 text-blue-500" />;
  return <File className="w-4 h-4 text-[var(--text-4)]" />;
};

export const FileAttachmentPreview: React.FC<Props> = ({ attachments, readOnly, onRemove }) => (
  <div className="flex flex-wrap gap-2">
    {attachments.map(att => (
      <div
        key={att.id}
        className="relative flex items-center gap-2 px-3 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--surface-3)] max-w-[220px]"
      >
        {iconFor(att.type)}
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium text-[var(--text-2)] truncate">{att.name}</p>
          <p className="text-[10px] text-[var(--text-4)]">
            {att.size < 1024 ? `${att.size}B` : `${(att.size / 1024).toFixed(1)}KB`}
          </p>
        </div>
        {!readOnly && onRemove && (
          <button
            onClick={() => onRemove(att.id)}
            className="p-0.5 rounded-md hover:bg-[var(--surface-3)] text-[var(--text-4)] hover:text-[var(--danger)]"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>
    ))}
  </div>
);
