import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Brain, Save, Sparkles } from 'lucide-react';

interface SystemPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
  onSave: (prompt: string) => void;
}

export const SystemPromptModal: React.FC<SystemPromptModalProps> = ({
  isOpen,
  onClose,
  initialPrompt = '',
  onSave
}) => {
  const [prompt, setPrompt] = useState(initialPrompt);

  useEffect(() => {
    setPrompt(initialPrompt);
  }, [initialPrompt, isOpen]);

  const handleSave = () => {
    onSave(prompt.trim());
    onClose();
  };

  const presetPrompts = [
    { title: 'Senior Software Engineer', text: 'You are an expert Senior Software Engineer specializing in TypeScript, React, Node.js, and clean software architecture. Provide concise, production-ready code with explanations.' },
    { title: 'Helpful AI Assistant', text: 'You are a helpful, empathetic, and knowledgeable AI assistant. Answer questions clearly with structured formatting.' },
    { title: 'Code Reviewer', text: 'You are an expert code reviewer. Analyze code for bugs, edge cases, security vulnerabilities, and performance optimizations.' }
  ];

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Custom System Prompt" maxWidth="max-w-xl">
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-xs text-[var(--text-secondary)]">
          <Brain className="w-4 h-4 text-purple-400" />
          <span>Set custom behavior instructions for this conversation.</span>
        </div>

        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g. You are a Senior Developer. Respond concisely with code blocks."
          rows={5}
          className="w-full p-3.5 text-xs rounded-xl bg-[var(--bg-primary)] border border-[var(--border-color)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:border-[var(--accent)] transition-all"
        />

        {/* Preset Chips */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wider block">
            Quick Presets
          </span>
          <div className="flex flex-wrap gap-1.5">
            {presetPrompts.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setPrompt(preset.text)}
                className="px-2.5 py-1 text-[11px] font-medium rounded-lg bg-[var(--bg-secondary)] border border-[var(--border-color)] hover:border-[var(--accent)] hover:bg-[var(--accent-light)] hover:text-[var(--accent)] text-[var(--text-secondary)] transition-all flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>{preset.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-[var(--border-color)]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium rounded-xl border border-[var(--border-color)] hover:bg-[var(--bg-tertiary)] text-[var(--text-secondary)] transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] transition-all flex items-center gap-1.5 shadow-md shadow-indigo-500/20"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save System Prompt</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
