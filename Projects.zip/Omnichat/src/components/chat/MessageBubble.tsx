import React, { useState } from 'react';
import { Message } from '../../types';
import { CodeBlock } from './CodeBlock';
import { FileAttachmentPreview } from './FileAttachmentPreview';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import {
  Copy, Check, RefreshCw, Pencil,
  ThumbsUp, ThumbsDown, Sparkles
} from 'lucide-react';

interface MessageBubbleProps {
  message: Message;
  isLastAssistant: boolean;
  isStreaming?: boolean;
  onRegenerate?: () => void;
  onEdit?: (id: string, content: string) => void;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message, isLastAssistant, isStreaming, onRegenerate, onEdit
}) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.content);
  const [vote, setVote] = useState<'up' | 'down' | null>(null);

  const copy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const saveEdit = () => {
    if (draft.trim() && draft.trim() !== message.content && onEdit) {
      onEdit(message.id, draft.trim());
    }
    setEditing(false);
  };

  /* ── User message - RIGHT aligned ── */
  if (isUser) {
    return (
      <div className="animate-msg mb-6 flex justify-end px-1">
        <div className="max-w-[80%] flex flex-col items-end">
          {/* Attachments */}
          {message.attachments && message.attachments.length > 0 && (
            <div className="mb-2"><FileAttachmentPreview attachments={message.attachments} readOnly /></div>
          )}

          {editing ? (
            <div className="flex flex-col gap-2 w-full min-w-[300px]">
              <textarea
                value={draft}
                onChange={e => setDraft(e.target.value)}
                rows={3}
                className="w-full p-3 text-sm rounded-2xl bg-[var(--surface-2)] border border-[var(--brand)] text-[var(--text-1)] focus:outline-none resize-none"
              />
              <div className="flex gap-2 justify-end">
                <button onClick={() => setEditing(false)} className="px-3 py-1.5 text-xs rounded-lg border border-[var(--surface-3)] text-[var(--text-3)] hover:bg-[var(--surface-2)]">Cancel</button>
                <button onClick={saveEdit} className="px-3 py-1.5 text-xs rounded-lg bg-[var(--brand)] text-white hover:opacity-90">Save & Resend</button>
              </div>
            </div>
          ) : (
            <>
              <div className="bg-[var(--user-bubble)] text-[var(--text-1)] rounded-3xl rounded-br-lg px-5 py-3 text-sm leading-relaxed whitespace-pre-wrap break-words">
                {message.content}
              </div>

              {/* Edit on hover */}
              <div className="mt-1 opacity-0 hover:opacity-100 transition-opacity">
                <button onClick={() => { setDraft(message.content); setEditing(true); }} className="p-1 rounded-md text-[var(--text-4)] hover:text-[var(--text-2)]" title="Edit">
                  <Pencil className="w-3 h-3" />
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  /* ── Assistant message - LEFT aligned ── */
  return (
    <div className="animate-msg mb-6 px-1">
      <div className="flex items-start gap-3">
        {/* AI Avatar */}
        <div className="w-7 h-7 rounded-full bg-[var(--brand-dim)] flex items-center justify-center flex-shrink-0 mt-0.5">
          <Sparkles className="w-3.5 h-3.5 text-[var(--brand)]" />
        </div>

        <div className="flex-1 min-w-0 max-w-[85%]">
          {/* Error */}
          {message.error && (
            <div className="text-xs text-red-500 mb-2 p-2.5 rounded-lg bg-red-500/10 border border-red-500/15">
              Failed to receive response from OmniRoute.
            </div>
          )}

          {/* Markdown body */}
          <div className="prose text-sm">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              rehypePlugins={[rehypeHighlight]}
              components={{
                code({ node, inline, className, children, ...props }: any) {
                  const match = /language-(\w+)/.exec(className || '');
                  return !inline && match ? (
                    <CodeBlock language={match[1]} code={String(children).replace(/\n$/, '')} />
                  ) : (
                    <code className={className} {...props}>{children}</code>
                  );
                }
              }}
            >
              {message.content}
            </ReactMarkdown>
            {isStreaming && <span className="cursor-blink inline-block w-[2px] h-[18px] bg-[var(--brand)] ml-0.5 align-text-bottom" />}
          </div>

          {/* Action toolbar - subtle, appears below */}
          {!isStreaming && message.content && (
            <div className="flex items-center gap-0.5 mt-2 opacity-0 hover:opacity-100 transition-opacity">
              <button onClick={copy} className="p-1.5 rounded-lg hover:bg-[var(--surface-2)] text-[var(--text-4)] hover:text-[var(--text-2)] transition-colors" title="Copy">
                {copied ? <Check className="w-3.5 h-3.5 text-[var(--success)]" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
              <button onClick={() => setVote(vote === 'up' ? null : 'up')} className={`p-1.5 rounded-lg hover:bg-[var(--surface-2)] transition-colors ${vote === 'up' ? 'text-[var(--success)]' : 'text-[var(--text-4)] hover:text-[var(--text-2)]'}`} title="Good">
                <ThumbsUp className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => setVote(vote === 'down' ? null : 'down')} className={`p-1.5 rounded-lg hover:bg-[var(--surface-2)] transition-colors ${vote === 'down' ? 'text-[var(--danger)]' : 'text-[var(--text-4)] hover:text-[var(--text-2)]'}`} title="Bad">
                <ThumbsDown className="w-3.5 h-3.5" />
              </button>
              {isLastAssistant && onRegenerate && (
                <button onClick={onRegenerate} className="p-1.5 rounded-lg hover:bg-[var(--surface-2)] text-[var(--text-4)] hover:text-[var(--text-2)] transition-colors" title="Regenerate">
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
