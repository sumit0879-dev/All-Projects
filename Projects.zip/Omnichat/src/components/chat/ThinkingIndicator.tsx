import React from 'react';
import { Sparkles } from 'lucide-react';

export const ThinkingIndicator: React.FC = () => (
  <div className="animate-msg flex items-start gap-3 mb-6 px-1">
    {/* AI Avatar */}
    <div className="w-7 h-7 rounded-full bg-[var(--brand-dim)] flex items-center justify-center flex-shrink-0 mt-0.5">
      <Sparkles className="w-3.5 h-3.5 text-[var(--brand)]" />
    </div>

    {/* Thinking dots */}
    <div className="flex items-center gap-1 pt-2.5">
      <span className="thinking-dot w-2 h-2 rounded-full bg-[var(--text-4)]" style={{ animationDelay: '0ms' }} />
      <span className="thinking-dot w-2 h-2 rounded-full bg-[var(--text-4)]" style={{ animationDelay: '150ms' }} />
      <span className="thinking-dot w-2 h-2 rounded-full bg-[var(--text-4)]" style={{ animationDelay: '300ms' }} />
    </div>
  </div>
);
