import React, { useRef, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import { useSettings } from '../../context/SettingsContext';
import { HeroScreen } from './HeroScreen';
import { MessageBubble } from './MessageBubble';
import { InputBar } from './InputBar';
import { ThinkingIndicator } from './ThinkingIndicator';

interface ChatAreaProps {
  sidebarOpen: boolean;
  onOpenSidebar: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({ sidebarOpen, onOpenSidebar }) => {
  const {
    messages, isStreaming, isLoadingMessages,
    activeError, setActiveError,
    sendMessage, stopGeneration, regenerateLastResponse, editUserMessage,
    selectedModel
  } = useChat();
  const { openSettings } = useSettings();

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isStreaming]);

  const hasMessages = messages.length > 0;

  // Check if last message is user (meaning AI is about to respond)
  const isWaitingForAI = isStreaming && messages.length > 0 && messages[messages.length - 1].role === 'user';
  // Check if AI is actively streaming text
  const isAIStreaming = isStreaming && messages.length > 0 && messages[messages.length - 1].role === 'assistant';

  return (
    <div className="flex-1 flex flex-col h-full min-w-0 bg-[var(--surface-0)]">

      {/* Error banner - only when needed */}
      {activeError && (
        <div className="px-4 py-2.5 bg-red-500/10 text-red-500 flex items-center justify-between text-xs">
          <span>{activeError}</span>
          <button onClick={() => setActiveError(null)} className="font-medium hover:underline">Dismiss</button>
        </div>
      )}

      {/* Messages area - NO header, clean like Claude */}
      {isLoadingMessages ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="flex items-center gap-2 text-xs text-[var(--text-4)]">
            <div className="w-4 h-4 rounded-full border-2 border-[var(--brand)] border-t-transparent animate-spin" />
            Loading…
          </div>
        </div>
      ) : !hasMessages ? (
        <HeroScreen onSend={sendMessage} />
      ) : (
        <div ref={scrollRef} className="flex-1 overflow-y-auto">
          <div className="max-w-[760px] mx-auto px-5 py-8">
            {messages.map((msg, i) => (
              <MessageBubble
                key={msg.id}
                message={msg}
                isLastAssistant={msg.role === 'assistant' && i === messages.length - 1}
                isStreaming={isAIStreaming && i === messages.length - 1}
                onRegenerate={regenerateLastResponse}
                onEdit={editUserMessage}
              />
            ))}

            {/* Thinking indicator when waiting for AI to start */}
            {isWaitingForAI && <ThinkingIndicator />}
          </div>
        </div>
      )}

      {/* Input bar */}
      <InputBar
        onSend={sendMessage}
        onStop={stopGeneration}
        isStreaming={isStreaming}
        disabled={isLoadingMessages}
        selectedModel={selectedModel}
        onOpenSidebar={!sidebarOpen ? onOpenSidebar : undefined}
      />
    </div>
  );
};
