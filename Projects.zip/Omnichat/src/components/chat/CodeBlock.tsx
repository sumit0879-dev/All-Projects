import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface CodeBlockProps {
  language: string;
  code: string;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="relative my-3 rounded-xl overflow-hidden border border-[var(--surface-3)]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-[var(--surface-2)] border-b border-[var(--surface-3)]">
        <span className="text-[11px] font-mono text-[var(--text-4)] uppercase tracking-wider">{language}</span>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 text-[11px] text-[var(--text-3)] hover:text-[var(--text-1)] transition-colors"
        >
          {copied ? <><Check className="w-3 h-3 text-[var(--success)]" /> Copied</> : <><Copy className="w-3 h-3" /> Copy</>}
        </button>
      </div>
      {/* Code */}
      <pre className="p-4 overflow-x-auto text-[13px] leading-relaxed bg-[var(--code-surface)] text-[var(--text-1)]">
        <code className={`language-${language} hljs`}>{code}</code>
      </pre>
    </div>
  );
};
