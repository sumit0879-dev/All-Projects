import React from 'react';
import { useSettings } from '../../context/SettingsContext';
import { Moon, Sun, Monitor } from 'lucide-react';

export const AppearanceTab: React.FC = () => {
  const { settings, setTheme } = useSettings();

  const themes: { id: 'dark' | 'light' | 'system'; label: string; icon: React.ReactNode }[] = [
    { id: 'dark', label: 'Dark', icon: <Moon className="w-5 h-5" /> },
    { id: 'light', label: 'Light', icon: <Sun className="w-5 h-5" /> },
    { id: 'system', label: 'System', icon: <Monitor className="w-5 h-5" /> }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xs font-semibold text-[var(--text-1)] mb-1">Theme</h3>
        <p className="text-xs text-[var(--text-4)]">Choose your visual preference.</p>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {themes.map(t => (
          <button
            key={t.id}
            onClick={() => setTheme(t.id)}
            className={`flex flex-col items-center justify-center p-5 rounded-xl border transition-all cursor-pointer ${
              settings.theme === t.id
                ? 'bg-[var(--brand-dim)] border-[var(--brand)] text-[var(--brand)]'
                : 'bg-[var(--surface-2)] border-[var(--surface-3)] text-[var(--text-4)] hover:text-[var(--text-1)] hover:border-[var(--text-4)]'
            }`}
          >
            {t.icon}
            <span className="text-xs font-medium mt-2">{t.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
