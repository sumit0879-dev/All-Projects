import React, { useState, useEffect } from 'react';
import { useSettings } from '../../context/SettingsContext';
import { runDiagnostic } from '../../services/api';
import { DiagnosticResult } from '../../types';
import { RefreshCw, CheckCircle2, XCircle, Clock, Server, Key, Cpu, ShieldCheck } from 'lucide-react';

export const DiagnosticPage: React.FC = () => {
  const { settings } = useSettings();
  const [diagnostic, setDiagnostic] = useState<DiagnosticResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  const run = async () => {
    setIsRunning(true);
    try {
      setDiagnostic(await runDiagnostic(settings.baseUrl, settings.apiKey));
    } catch {} finally { setIsRunning(false); }
  };

  useEffect(() => { run(); }, []);

  const Row: React.FC<{ icon: React.ReactNode; title: string; desc: string; ok?: boolean; value?: string }> = ({ icon, title, desc, ok, value }) => (
    <div className="p-3.5 rounded-xl bg-[var(--surface-2)] border border-[var(--surface-3)] flex items-center justify-between text-xs">
      <div className="flex items-center gap-3">
        {icon}
        <div>
          <span className="font-semibold block text-[var(--text-1)]">{title}</span>
          <span className="text-[var(--text-4)] text-[11px]">{desc}</span>
        </div>
      </div>
      {value
        ? <span className="font-mono text-emerald-500 font-semibold">{value}</span>
        : ok ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <XCircle className="w-4 h-4 text-red-500" />
      }
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-semibold text-[var(--text-1)]">Diagnostics</h3>
          <p className="text-xs text-[var(--text-4)]">Verify connectivity to OmniRoute.</p>
        </div>
        <button onClick={run} disabled={isRunning} className="px-3 py-1.5 text-xs font-medium rounded-xl border border-[var(--surface-3)] hover:bg-[var(--surface-2)] text-[var(--text-1)] transition-colors flex items-center gap-1.5">
          <RefreshCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} /> Re-run
        </button>
      </div>

      {diagnostic ? (
        <div className="space-y-2">
          <Row icon={<Server className="w-4 h-4 text-indigo-400" />} title="Base URL" desc={diagnostic.baseUrl} ok />
          <Row icon={<ShieldCheck className="w-4 h-4 text-purple-400" />} title="Server Reachable" desc={diagnostic.serverReachable ? 'Listening' : 'Offline'} ok={diagnostic.serverReachable} />
          <Row icon={<Key className="w-4 h-4 text-amber-400" />} title="Auth Valid" desc={diagnostic.authValid ? 'Token accepted' : 'Invalid key'} ok={diagnostic.authValid} />
          <Row icon={<Cpu className="w-4 h-4 text-emerald-400" />} title="Models" desc={diagnostic.modelsWorking ? `${diagnostic.modelsCount} models` : 'Failed'} ok={diagnostic.modelsWorking} />
          <Row icon={<Clock className="w-4 h-4 text-blue-400" />} title="Latency" desc="Round-trip" value={`${diagnostic.latencyMs}ms`} />

          <div className="p-3 rounded-xl bg-[var(--surface-2)] border border-[var(--surface-3)] text-xs text-[var(--text-3)]">
            <span className="font-semibold text-[var(--text-1)] block mb-1">Status:</span>
            {diagnostic.message}
          </div>
        </div>
      ) : (
        <div className="p-8 text-center text-xs text-[var(--text-4)]">Running diagnostics…</div>
      )}
    </div>
  );
};
