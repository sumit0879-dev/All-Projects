import React, { useState } from 'react';
import { useSettings } from '../../context/SettingsContext';
import { Terminal, Copy, Check, HelpCircle } from 'lucide-react';

export const HelpTab: React.FC = () => {
  const { settings } = useSettings();
  const [copied, setCopied] = useState(false);

  const copySettings = () => {
    navigator.clipboard.writeText(`Base URL: ${settings.baseUrl}\nAPI Key: ${settings.apiKey ? '(set)' : '(none)'}\nModel: ${settings.defaultModel}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 text-xs text-[var(--text-3)] leading-relaxed">
      <div className="flex items-center justify-between pb-3 border-b border-[var(--surface-3)]">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-[var(--brand)]" />
          <h3 className="font-bold text-sm text-[var(--text-1)]">Quick Start</h3>
        </div>
        <button onClick={copySettings} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-3)] text-[var(--text-1)] transition-colors">
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied!' : 'Copy Settings'}</span>
        </button>
      </div>

      <ol className="space-y-4 list-decimal list-inside">
        <li>
          <strong className="text-[var(--text-1)]">Start OmniRoute:</strong>
          <div className="ml-5 mt-1.5 p-3 rounded-xl bg-[var(--code-surface)] text-emerald-400 font-mono flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[var(--text-4)]" /> omniroute
          </div>
        </li>
        <li>
          <strong className="text-[var(--text-1)]">Default endpoint:</strong>
          <div className="ml-5 mt-1.5 p-2 px-3 rounded-xl bg-[var(--surface-2)] text-[var(--text-1)] font-mono">http://localhost:20128/v1</div>
        </li>
        <li><strong className="text-[var(--text-1)]">Configure:</strong> Enter Base URL and API key in the Connection tab.</li>
        <li><strong className="text-[var(--text-1)]">Test & Fetch Models:</strong> Click Test, then Fetch Models. Select Auto or a specific model.</li>
      </ol>

      <div className="p-4 rounded-xl bg-[var(--surface-2)] border border-[var(--surface-3)]">
        <span className="font-semibold text-[var(--text-1)] block mb-1">🔒 Local-First</span>
        <p className="text-[11px] text-[var(--text-4)]">
          OmniChat runs entirely on your machine. Prompts go from browser → Node backend → OmniRoute. No external servers, no telemetry.
        </p>
      </div>
    </div>
  );
};
