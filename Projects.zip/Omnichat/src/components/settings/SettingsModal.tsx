import React, { useState, useEffect } from 'react';
import { useSettings } from '../../context/SettingsContext';
import { Modal } from '../common/Modal';
import { ConnectionTab } from './ConnectionTab';
import { ModelsTab } from './ModelsTab';
import { AppearanceTab } from './AppearanceTab';
import { DiagnosticPage } from './DiagnosticPage';
import { HelpTab } from './HelpTab';
import { Wifi, Cpu, Palette, Activity, HelpCircle } from 'lucide-react';

export const SettingsModal: React.FC = () => {
  const { isSettingsOpen, closeSettings, activeSettingsTab } = useSettings();
  const [currentTab, setCurrentTab] = useState<string>('connection');

  useEffect(() => {
    if (activeSettingsTab) setCurrentTab(activeSettingsTab);
  }, [activeSettingsTab]);

  const tabs = [
    { id: 'connection', label: 'Connection', icon: <Wifi className="w-4 h-4" /> },
    { id: 'models', label: 'Models', icon: <Cpu className="w-4 h-4" /> },
    { id: 'appearance', label: 'Appearance', icon: <Palette className="w-4 h-4" /> },
    { id: 'diagnostic', label: 'Diagnostic', icon: <Activity className="w-4 h-4" /> },
    { id: 'help', label: 'Help', icon: <HelpCircle className="w-4 h-4" /> }
  ];

  return (
    <Modal isOpen={isSettingsOpen} onClose={closeSettings} title="Settings" maxWidth="max-w-3xl">
      <div className="flex flex-col md:flex-row gap-6 min-h-[400px]">
        {/* Tabs */}
        <div className="w-full md:w-44 flex md:flex-col gap-1 border-b md:border-b-0 md:border-r border-[var(--surface-3)] pb-3 md:pb-0 md:pr-4">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id)}
              className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                currentTab === tab.id
                  ? 'bg-[var(--brand-dim)] text-[var(--brand)] font-semibold'
                  : 'text-[var(--text-3)] hover:text-[var(--text-1)] hover:bg-[var(--surface-2)]'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {currentTab === 'connection' && <ConnectionTab />}
          {currentTab === 'models' && <ModelsTab />}
          {currentTab === 'appearance' && <AppearanceTab />}
          {currentTab === 'diagnostic' && <DiagnosticPage />}
          {currentTab === 'help' && <HelpTab />}
        </div>
      </div>
    </Modal>
  );
};
