import React, { useState } from 'react';
import { useSettings } from '../../context/SettingsContext';
import { Eye, EyeOff, RefreshCw, CheckCircle, AlertCircle, Save, RotateCcw } from 'lucide-react';

export const ConnectionTab: React.FC = () => {
  const { settings, updateSettings, resetSettings, checkConnection, loadModels } = useSettings();

  const [baseUrlInput, setBaseUrlInput] = useState(settings.baseUrl || 'http://localhost:20128/v1');
  const [apiKeyInput, setApiKeyInput] = useState(settings.apiKey || '');
  const [showApiKey, setShowApiKey] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const handleTestConnection = async () => {
    setIsTesting(true); setTestResult(null);
    try {
      const ok = await checkConnection(baseUrlInput, apiKeyInput);
      setTestResult({ success: ok, message: ok ? 'Connected to OmniRoute!' : 'Connection failed. Verify OmniRoute is running.' });
    } catch (err: any) {
      setTestResult({ success: false, message: `Error: ${err.message}` });
    } finally { setIsTesting(false); }
  };

  const handleFetchModels = async () => {
    setIsTesting(true);
    try {
      const models = await loadModels(baseUrlInput, apiKeyInput);
      setTestResult({ success: true, message: `Fetched ${models.length} models from OmniRoute` });
    } catch (err: any) {
      setTestResult({ success: false, message: `Failed: ${err.message}` });
    } finally { setIsTesting(false); }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await updateSettings({ baseUrl: baseUrlInput.trim(), apiKey: apiKeyInput.trim() });
      await checkConnection(baseUrlInput.trim(), apiKeyInput.trim());
      setTestResult({ success: true, message: 'Settings saved!' });
    } catch (err: any) {
      setTestResult({ success: false, message: `Failed: ${err.message}` });
    } finally { setIsSaving(false); }
  };

  const handleReset = async () => {
    const res = await resetSettings();
    setBaseUrlInput(res.baseUrl);
    setApiKeyInput('');
    setTestResult({ success: true, message: 'Reset to defaults' });
  };

  const inputCls = "w-full px-3.5 py-2.5 text-xs font-mono rounded-xl bg-[var(--surface-0)] border border-[var(--surface-3)] text-[var(--text-1)] focus:outline-none focus:border-[var(--brand)] transition-colors";

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <label className="block text-xs font-semibold text-[var(--text-1)]">OmniRoute Base URL</label>
        <input type="text" value={baseUrlInput} onChange={e => setBaseUrlInput(e.target.value)} placeholder="http://localhost:20128/v1" className={inputCls} />
        <p className="text-[11px] text-[var(--text-4)]">
          Default: <code className="bg-[var(--surface-2)] px-1 py-0.5 rounded text-[var(--text-3)]">http://localhost:20128/v1</code>
        </p>
      </div>

      <div className="space-y-2">
        <label className="block text-xs font-semibold text-[var(--text-1)]">OmniRoute API Key</label>
        <div className="relative flex items-center">
          <input type={showApiKey ? 'text' : 'password'} value={apiKeyInput} onChange={e => setApiKeyInput(e.target.value)} placeholder="Enter API Key…" className={inputCls + ' pr-10'} />
          <button type="button" onClick={() => setShowApiKey(!showApiKey)} className="absolute right-3 text-[var(--text-4)] hover:text-[var(--text-1)] p-1 rounded transition-colors">
            {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        <p className="text-[11px] text-[var(--text-4)]">Saved locally — never shared externally.</p>
      </div>

      <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-[var(--surface-3)]">
        <button type="button" onClick={handleTestConnection} disabled={isTesting} className="px-4 py-2 text-xs font-medium rounded-xl border border-[var(--surface-3)] hover:bg-[var(--surface-2)] text-[var(--text-1)] transition-colors flex items-center gap-2">
          {isTesting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />} Test
        </button>
        <button type="button" onClick={handleFetchModels} disabled={isTesting} className="px-4 py-2 text-xs font-medium rounded-xl border border-[var(--surface-3)] hover:bg-[var(--surface-2)] text-[var(--text-1)] transition-colors">
          Fetch Models
        </button>
        <div className="ml-auto flex items-center gap-2">
          <button type="button" onClick={handleReset} className="px-3 py-2 text-xs rounded-xl text-[var(--text-4)] hover:text-[var(--danger)] hover:bg-red-500/10 transition-colors flex items-center gap-1.5">
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>
          <button type="button" onClick={handleSave} disabled={isSaving} className="px-4 py-2 text-xs font-semibold rounded-xl bg-[var(--brand)] text-white hover:opacity-90 transition-all flex items-center gap-1.5">
            <Save className="w-3.5 h-3.5" /> {isSaving ? 'Saving…' : 'Save'}
          </button>
        </div>
      </div>

      {testResult && (
        <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${testResult.success ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}>
          {testResult.success ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{testResult.message}</span>
        </div>
      )}
    </div>
  );
};
