import React from 'react';
import { useSettings } from '../../context/SettingsContext';
import { Sparkles, Sliders } from 'lucide-react';

export const ModelsTab: React.FC = () => {
  const { settings, updateSettings, models } = useSettings();

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-[var(--brand-dim)] border border-[var(--surface-3)] space-y-1">
        <div className="flex items-center gap-2 text-xs font-semibold text-[var(--brand)]">
          <Sparkles className="w-4 h-4" /> Auto Router
        </div>
        <p className="text-[11px] text-[var(--text-3)] leading-relaxed">
          When <strong>"auto"</strong> is selected, OmniRoute dynamically picks the best available model.
        </p>
      </div>

      <div className="space-y-2">
        <label className="block text-xs font-semibold text-[var(--text-1)]">Default Model</label>
        <select
          value={settings.defaultModel}
          onChange={e => updateSettings({ defaultModel: e.target.value })}
          className="w-full px-3.5 py-2.5 text-xs rounded-xl bg-[var(--surface-0)] border border-[var(--surface-3)] text-[var(--text-1)] focus:outline-none focus:border-[var(--brand)] cursor-pointer"
        >
          {models.map(m => <option key={m.id} value={m.id}>{m.name || m.id}</option>)}
        </select>
      </div>

      <div className="space-y-4 pt-4 border-t border-[var(--surface-3)]">
        <div className="flex items-center gap-2 text-xs font-semibold text-[var(--text-1)]">
          <Sliders className="w-4 h-4 text-[var(--brand)]" /> Parameters
        </div>

        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-[var(--text-3)]">Temperature</span>
            <span className="font-mono text-[var(--brand)]">{settings.temperature}</span>
          </div>
          <input type="range" min="0" max="2" step="0.1" value={settings.temperature} onChange={e => updateSettings({ temperature: parseFloat(e.target.value) })} className="w-full accent-[var(--brand)] cursor-pointer" />
          <div className="flex justify-between text-[10px] text-[var(--text-4)]">
            <span>Precise</span><span>Balanced</span><span>Creative</span>
          </div>
        </div>

        <div className="space-y-1.5 pt-2">
          <div className="flex justify-between text-xs">
            <span className="text-[var(--text-3)]">Max Tokens</span>
            <span className="font-mono text-[var(--brand)]">{settings.maxTokens}</span>
          </div>
          <input type="range" min="256" max="16384" step="256" value={settings.maxTokens} onChange={e => updateSettings({ maxTokens: parseInt(e.target.value, 10) })} className="w-full accent-[var(--brand)] cursor-pointer" />
        </div>
      </div>
    </div>
  );
};
