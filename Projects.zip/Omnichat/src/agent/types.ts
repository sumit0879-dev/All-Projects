/**
 * Clean interfaces for future coding agent functionality.
 * Designed so that agentic capabilities can be plugged in seamlessly
 * without rewriting the OmniChat GUI.
 */

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, any>;
  status: 'pending' | 'executing' | 'completed' | 'failed';
  result?: any;
  error?: string;
}

export interface FileOperation {
  type: 'read' | 'write' | 'edit' | 'delete' | 'list';
  path: string;
  content?: string;
  startLine?: number;
  endLine?: number;
}

export interface TerminalCommand {
  id: string;
  command: string;
  cwd: string;
  status: 'running' | 'completed' | 'failed';
  output: string;
  exitCode?: number;
}

export interface AgentLoopState {
  isAgentActive: boolean;
  currentTask?: string;
  toolHistory: ToolCall[];
  terminalHistory: TerminalCommand[];
  activeFiles: string[];
}

export interface AgentStreamingEvent {
  type: 'token' | 'tool_start' | 'tool_end' | 'file_change' | 'terminal_output' | 'error';
  payload: any;
  timestamp: number;
}

export interface AgentConfig {
  autoApproveTools: boolean;
  allowedCommands: string[];
  workspaceRoot: string;
  maxIterations: number;
}
