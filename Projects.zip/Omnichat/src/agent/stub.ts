import { AgentLoopState, AgentConfig, ToolCall } from './types';

/**
 * Placeholder stub for future Agent Loop module.
 * Provides ready-to-wire hooks for upcoming coding agent features.
 */

export const initialAgentState: AgentLoopState = {
  isAgentActive: false,
  toolHistory: [],
  terminalHistory: [],
  activeFiles: []
};

export function executeAgentTool(tool: ToolCall, _config?: AgentConfig): Promise<ToolCall> {
  console.warn('[Agent Stub] Tool execution requested but Agent module is disabled in v1.0:', tool.name);
  return Promise.resolve({
    ...tool,
    status: 'failed',
    error: 'Coding agent tools will be enabled in a future release.'
  });
}
