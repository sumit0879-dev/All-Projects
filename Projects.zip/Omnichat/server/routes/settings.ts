import { Router, Request, Response } from 'express';
import { getSettings, saveSettings, resetSettings } from '../db.js';

const router = Router();

// Mask secret API keys for frontend display safety
function formatSafeSettings(settings: ReturnType<typeof getSettings>) {
  const hasKey = Boolean(settings.apiKey && settings.apiKey.trim().length > 0);
  let maskedKey = '';
  if (hasKey) {
    const key = settings.apiKey.trim();
    if (key.length > 8) {
      maskedKey = key.slice(0, 4) + '••••••••' + key.slice(-4);
    } else {
      maskedKey = '••••••••';
    }
  }

  return {
    ...settings,
    hasApiKey: hasKey,
    maskedApiKey: maskedKey,
    // Note: We still return apiKey if user asks, but frontend should handle masking safely
  };
}

router.get('/', (_req: Request, res: Response) => {
  try {
    const settings = getSettings();
    return res.json({ success: true, settings: formatSafeSettings(settings) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/', (req: Request, res: Response) => {
  try {
    const updates = req.body;
    if (updates.baseUrl) {
      // Normalize base URL: strip trailing slash
      updates.baseUrl = updates.baseUrl.trim().replace(/\/+$/, '');
    }
    const updated = saveSettings(updates);
    return res.json({ success: true, settings: formatSafeSettings(updated) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/reset', (_req: Request, res: Response) => {
  try {
    const defaultSettings = resetSettings();
    return res.json({ success: true, settings: formatSafeSettings(defaultSettings) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
