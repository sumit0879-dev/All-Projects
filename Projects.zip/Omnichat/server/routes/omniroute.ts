import { Router, Request, Response } from 'express';
import { getSettings, addMessage } from '../db.js';
import { ConnectionTestResult, OmniRouteModelsResponse } from '../types.js';

const router = Router();

// Helper to sanitize headers for fetch calls
function getAuthHeaders(apiKey?: string) {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  };
  if (apiKey && apiKey.trim().length > 0) {
    headers['Authorization'] = `Bearer ${apiKey.trim()}`;
  }
  return headers;
}

// Test OmniRoute Server Reachability & Authentication
router.post('/test', async (req: Request, res: Response) => {
  const settings = getSettings();
  const baseUrl = (req.body.baseUrl || settings.baseUrl || 'http://localhost:20128/v1').trim().replace(/\/+$/, '');
  const apiKey = req.body.apiKey !== undefined ? req.body.apiKey : settings.apiKey;

  const startTime = Date.now();
  const modelsUrl = `${baseUrl}/models`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 7000); // 7s timeout for diagnostic test

    const response = await fetch(modelsUrl, {
      method: 'GET',
      headers: getAuthHeaders(apiKey),
      signal: controller.signal
    });

    clearTimeout(timeout);
    const latencyMs = Date.now() - startTime;

    if (response.ok) {
      const data = await response.json() as OmniRouteModelsResponse;
      const count = Array.isArray(data.data) ? data.data.length : 0;

      const result: ConnectionTestResult = {
        success: true,
        message: `Successfully connected to OmniRoute! (${count} models found, ${latencyMs}ms)`,
        modelsCount: count,
        latencyMs
      };
      return res.json(result);
    }

    if (response.status === 401 || response.status === 403) {
      return res.json({
        success: false,
        message: `Authentication failed (Status ${response.status}). Check your OmniRoute API Key in Settings.`,
        errorType: 'invalid_key',
        latencyMs
      });
    }

    return res.json({
      success: false,
      message: `OmniRoute responded with error status ${response.status}: ${response.statusText}`,
      errorType: 'unknown',
      latencyMs
    });
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    if (err.name === 'AbortError') {
      return res.json({
        success: false,
        message: `Connection timed out after 7s while reaching ${baseUrl}`,
        errorType: 'timeout',
        latencyMs
      });
    }

    const code = err.cause?.code || err.code;
    if (code === 'ECONNREFUSED' || err.message?.includes('fetch failed')) {
      return res.json({
        success: false,
        message: `Connection refused at ${baseUrl}. Ensure OmniRoute is running locally (\`omniroute\`).`,
        errorType: 'connection_refused',
        latencyMs
      });
    }

    return res.json({
      success: false,
      message: `OmniRoute server unavailable: ${err.message}`,
      errorType: 'server_unavailable',
      latencyMs
    });
  }
});

// Fetch Available Models from OmniRoute
router.get('/models', async (req: Request, res: Response) => {
  const settings = getSettings();
  const baseUrl = ((req.query.baseUrl as string) || settings.baseUrl || 'http://localhost:20128/v1').trim().replace(/\/+$/, '');
  const apiKey = (req.query.apiKey as string) !== undefined ? (req.query.apiKey as string) : settings.apiKey;

  try {
    const modelsUrl = `${baseUrl}/models`;
    const response = await fetch(modelsUrl, {
      method: 'GET',
      headers: getAuthHeaders(apiKey)
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({
        success: false,
        error: `Failed to fetch models from OmniRoute (${response.status}): ${errText}`
      });
    }

    const data = await response.json() as OmniRouteModelsResponse;
    const rawModels = Array.isArray(data.data) ? data.data : [];

    // Prepend Auto model option
    const models = [
      { id: 'auto', name: 'Auto (OmniRoute Router)', provider: 'omniroute' },
      ...rawModels.map(m => ({
        id: m.id,
        name: m.id,
        ownedBy: m.owned_by || 'provider'
      }))
    ];

    return res.json({ success: true, models, raw: data });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: `OmniRoute connection failed: ${err.message}. Make sure OmniRoute is running with \`omniroute\` command.`
    });
  }
});

// Stream Chat Completions Proxy (SSE)
router.post('/chat', async (req: Request, res: Response) => {
  const settings = getSettings();
  const { conversationId, messages, model, temperature, maxTokens, stream = true } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required' });
  }

  const baseUrl = (settings.baseUrl || 'http://localhost:20128/v1').trim().replace(/\/+$/, '');
  const chatUrl = `${baseUrl}/chat/completions`;

  // Build clean request body for OmniRoute (OpenAI compatible)
  const selectedModel = model || settings.defaultModel || 'auto';
  const requestPayload: Record<string, any> = {
    model: selectedModel,
    messages: messages.map(m => ({ role: m.role, content: m.content })),
    stream: stream !== false
  };

  if (temperature !== undefined && temperature !== null) {
    requestPayload.temperature = temperature;
  }
  if (maxTokens !== undefined && maxTokens !== null) {
    requestPayload.max_tokens = maxTokens;
  }

  try {
    const upstreamResponse = await fetch(chatUrl, {
      method: 'POST',
      headers: getAuthHeaders(settings.apiKey),
      body: JSON.stringify(requestPayload)
    });

    if (!upstreamResponse.ok) {
      const errText = await upstreamResponse.text();
      console.error('[OmniRoute Proxy Error]', upstreamResponse.status, errText);
      return res.status(upstreamResponse.status).json({
        error: `OmniRoute Error (${upstreamResponse.status}): ${errText || upstreamResponse.statusText}`
      });
    }

    // Set SSE headers on client response
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');

    if (!upstreamResponse.body) {
      res.write(`data: ${JSON.stringify({ error: 'Empty response body from OmniRoute' })}\n\n`);
      res.write('data: [DONE]\n\n');
      return res.end();
    }

    const reader = upstreamResponse.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let fullAssistantResponse = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      res.write(chunk);

      // Parse chunk tokens to construct full message for SQLite save
      const lines = chunk.split('\n');
      for (const line of lines) {
        if (line.startsWith('data: ') && !line.includes('[DONE]')) {
          try {
            const jsonStr = line.slice(6).trim();
            if (jsonStr) {
              const parsed = JSON.parse(jsonStr);
              const deltaContent = parsed.choices?.[0]?.delta?.content;
              if (deltaContent) {
                fullAssistantResponse += deltaContent;
              }
            }
          } catch (e) {
            // Ignore partial SSE JSON chunk parse errors
          }
        }
      }
    }

    res.write('data: [DONE]\n\n');
    res.end();

    // Store completed assistant message in SQLite if conversationId provided
    if (conversationId && fullAssistantResponse.trim()) {
      addMessage({
        id: 'msg-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
        conversationId,
        role: 'assistant',
        content: fullAssistantResponse,
        model: selectedModel
      });
    }

    return;
  } catch (err: any) {
    console.error('[OmniRoute Proxy Request Exception]', err);
    if (!res.headersSent) {
      return res.status(502).json({
        error: `Failed to communicate with OmniRoute server at ${baseUrl}: ${err.message}`
      });
    } else {
      res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
      res.write('data: [DONE]\n\n');
      return res.end();
    }
  }
});

export default router;
