import { Router, Request, Response } from 'express';
import {
  getAllConversations,
  getConversationById,
  createConversation,
  updateConversation,
  deleteConversation,
  addMessage,
  truncateMessagesFrom
} from '../db.js';

const router = Router();

// Get all conversations
router.get('/', (_req: Request, res: Response) => {
  try {
    const list = getAllConversations();
    return res.json({ success: true, conversations: list });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Create conversation
router.post('/', (req: Request, res: Response) => {
  try {
    const { title = 'New Chat', model = 'auto', systemPrompt, temperature = 0.7, maxTokens = 4096 } = req.body;
    const id = 'conv-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
    const conversation = createConversation({
      id,
      title,
      model,
      systemPrompt,
      temperature,
      maxTokens
    });
    return res.json({ success: true, conversation });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Get single conversation with full message history
router.get('/:id', (req: Request, res: Response) => {
  try {
    const data = getConversationById(req.params.id);
    if (!data) {
      return res.status(404).json({ success: false, error: 'Conversation not found' });
    }
    return res.json({ success: true, ...data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Rename / Update conversation model or settings
router.patch('/:id', (req: Request, res: Response) => {
  try {
    const updated = updateConversation(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Conversation not found' });
    }
    return res.json({ success: true, conversation: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Delete conversation
router.delete('/:id', (req: Request, res: Response) => {
  try {
    const deleted = deleteConversation(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, error: 'Conversation not found' });
    }
    return res.json({ success: true, message: 'Conversation deleted' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Add message to conversation
router.post('/:id/messages', (req: Request, res: Response) => {
  try {
    const { role, content, model } = req.body;
    if (!role || !content) {
      return res.status(400).json({ success: false, error: 'Role and content are required' });
    }

    const msgId = 'msg-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
    const message = addMessage({
      id: msgId,
      conversationId: req.params.id,
      role,
      content,
      model
    });

    return res.json({ success: true, message });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Truncate messages from a specific message ID (for edit message & regenerate)
router.delete('/:id/messages/truncate', (req: Request, res: Response) => {
  try {
    const { fromMessageId } = req.body;
    if (!fromMessageId) {
      return res.status(400).json({ success: false, error: 'fromMessageId is required' });
    }

    const truncated = truncateMessagesFrom(req.params.id, fromMessageId);
    return res.json({ success: true, truncated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
