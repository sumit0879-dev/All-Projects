import path from 'path';
import fs from 'fs';
import { Conversation, Message, AppSettings } from './types.js';

const storageFilePath = path.resolve(process.cwd(), 'omnichat-storage.json');

interface StorageData {
  settings: Record<string, string>;
  conversations: Conversation[];
  messages: Record<string, Message[]>;
}

const DEFAULT_SETTINGS: AppSettings = {
  baseUrl: 'http://localhost:20128/v1',
  apiKey: '',
  defaultModel: 'auto',
  theme: 'dark',
  temperature: 0.7,
  maxTokens: 4096,
  streaming: true
};

let memoryStore: StorageData = {
  settings: {},
  conversations: [],
  messages: {}
};

function loadStorage() {
  if (fs.existsSync(storageFilePath)) {
    try {
      const raw = fs.readFileSync(storageFilePath, 'utf-8');
      const parsed = JSON.parse(raw);
      memoryStore = {
        settings: parsed.settings || {},
        conversations: parsed.conversations || [],
        messages: parsed.messages || {}
      };
    } catch (e) {
      console.error('[Storage] Error loading storage file, initializing new store:', e);
    }
  }
}

function saveStorage() {
  try {
    fs.writeFileSync(storageFilePath, JSON.stringify(memoryStore, null, 2), 'utf-8');
  } catch (e) {
    console.error('[Storage] Error saving storage file:', e);
  }
}

export function initDatabase() {
  loadStorage();
  console.log('[Storage] Local storage initialized at', storageFilePath);
}

export function getSettings(): AppSettings {
  const settings = { ...DEFAULT_SETTINGS };
  for (const key of Object.keys(DEFAULT_SETTINGS) as (keyof AppSettings)[]) {
    const val = memoryStore.settings[key];
    if (val !== undefined) {
      if (typeof DEFAULT_SETTINGS[key] === 'number') {
        (settings as any)[key] = Number(val);
      } else if (typeof DEFAULT_SETTINGS[key] === 'boolean') {
        (settings as any)[key] = val === 'true';
      } else {
        (settings as any)[key] = val;
      }
    }
  }
  return settings;
}

export function saveSettings(updates: Partial<AppSettings>): AppSettings {
  Object.entries(updates).forEach(([k, v]) => {
    if (v !== undefined) {
      memoryStore.settings[k] = String(v);
    }
  });
  saveStorage();
  return getSettings();
}

export function resetSettings(): AppSettings {
  memoryStore.settings = {};
  saveStorage();
  return DEFAULT_SETTINGS;
}

// Conversation DB Actions
export function getAllConversations(): Conversation[] {
  return [...memoryStore.conversations].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return b.updatedAt - a.updatedAt;
  });
}

export function getConversationById(id: string): { conversation: Conversation; messages: Message[] } | null {
  const conversation = memoryStore.conversations.find(c => c.id === id);
  if (!conversation) return null;
  const messages = memoryStore.messages[id] || [];
  return { conversation, messages };
}

export function createConversation(conv: Omit<Conversation, 'createdAt' | 'updatedAt'>): Conversation {
  const now = Date.now();
  const fullConv: Conversation = {
    ...conv,
    isPinned: false,
    createdAt: now,
    updatedAt: now
  };

  memoryStore.conversations.push(fullConv);
  memoryStore.messages[fullConv.id] = [];
  saveStorage();
  return fullConv;
}

export function updateConversation(id: string, updates: Partial<{ title: string; model: string; systemPrompt: string; temperature: number; maxTokens: number; isPinned: boolean }>): Conversation | null {
  const now = Date.now();
  const index = memoryStore.conversations.findIndex(c => c.id === id);
  if (index === -1) return null;

  const existing = memoryStore.conversations[index];
  const updated = { ...existing, ...updates, updatedAt: now };
  memoryStore.conversations[index] = updated;
  saveStorage();
  return updated;
}

export function deleteConversation(id: string): boolean {
  const initialLen = memoryStore.conversations.length;
  memoryStore.conversations = memoryStore.conversations.filter(c => c.id !== id);
  delete memoryStore.messages[id];
  saveStorage();
  return memoryStore.conversations.length < initialLen;
}

export function addMessage(msg: Omit<Message, 'createdAt'>): Message {
  const now = Date.now();
  const fullMsg: Message = { ...msg, createdAt: now };

  if (!memoryStore.messages[msg.conversationId]) {
    memoryStore.messages[msg.conversationId] = [];
  }
  memoryStore.messages[msg.conversationId].push(fullMsg);

  // Update conversation title automatically from first user message if title is default
  const conv = memoryStore.conversations.find(c => c.id === msg.conversationId);
  if (conv) {
    const userMsgs = memoryStore.messages[msg.conversationId].filter(m => m.role === 'user');
    if (msg.role === 'user' && userMsgs.length === 1) {
      const titleSnippet = msg.content.trim().slice(0, 36) + (msg.content.length > 36 ? '...' : '');
      conv.title = titleSnippet || 'New Chat';
    }
    conv.updatedAt = now;
  }

  saveStorage();
  return fullMsg;
}

export function truncateMessagesFrom(conversationId: string, fromMessageId: string): boolean {
  const list = memoryStore.messages[conversationId] || [];
  const index = list.findIndex(m => m.id === fromMessageId);
  if (index !== -1) {
    memoryStore.messages[conversationId] = list.slice(0, index);
    saveStorage();
    return true;
  }
  return false;
}
