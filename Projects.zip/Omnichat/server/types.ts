export interface FileAttachment {
  id: string;
  name: string;
  size: number;
  type: string;
  content?: string;
  dataUrl?: string;
}

export interface AppSettings {
  baseUrl: string;
  apiKey: string;
  defaultModel: string;
  theme: 'dark' | 'light' | 'system';
  temperature: number;
  maxTokens: number;
  streaming: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  model: string;
  systemPrompt?: string;
  temperature: number;
  maxTokens: number;
  isPinned?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  model?: string;
  attachments?: FileAttachment[];
  createdAt: number;
}

export interface OmniRouteModel {
  id: string;
  object?: string;
  created?: number;
  owned_by?: string;
  permission?: any[];
  root?: string;
  parent?: string;
}

export interface OmniRouteModelsResponse {
  object: string;
  data: OmniRouteModel[];
}

export interface ConnectionTestResult {
  success: boolean;
  message: string;
  modelsCount?: number;
  latencyMs?: number;
  errorType?: 'server_unavailable' | 'invalid_key' | 'timeout' | 'connection_refused' | 'unknown';
}
