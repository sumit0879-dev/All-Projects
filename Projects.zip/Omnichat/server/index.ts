import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase } from './db.js';

import settingsRouter from './routes/settings.js';
import omnirouteRouter from './routes/omniroute.js';
import conversationsRouter from './routes/conversations.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// CORS setup
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Initialize SQLite database
initDatabase();

// API Health Endpoint
app.get('/api/health', (_req, res) => {
  return res.json({
    status: 'ok',
    appName: 'OmniChat Backend',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Register API Route modules
app.use('/api/settings', settingsRouter);
app.use('/api/omniroute', omnirouteRouter);
app.use('/api/conversations', conversationsRouter);

// Serve static frontend build if dist directory exists
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.resolve(__dirname, '../dist');

app.use(express.static(distPath));

// Fallback for SPA routing
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) {
    return next();
  }
  const indexPath = path.join(distPath, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      res.status(404).send('OmniChat server running. Client build not found in /dist yet.');
    }
  });
});

app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🚀 OmniChat Local Proxy Server running at:`);
  console.log(`   http://localhost:${PORT}`);
  console.log(`====================================================`);
});
