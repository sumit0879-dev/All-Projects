import { getSettings, saveSettings, resetSettings } from './db.js';
import { AppSettings } from './types.js';

export function loadConfig(): AppSettings {
  return getSettings();
}

export function updateConfig(updates: Partial<AppSettings>): AppSettings {
  return saveSettings(updates);
}

export function restoreDefaultConfig(): AppSettings {
  return resetSettings();
}
