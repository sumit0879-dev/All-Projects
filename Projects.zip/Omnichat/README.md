# OmniChat 🌐

OmniChat is a local-first, ChatGPT/Claude-style web application built as a dedicated GUI frontend for **OmniRoute**.

It allows you to have fast, rich AI conversations powered by your local OmniRoute server with full support for dynamic model routing, markdown rendering, syntax-highlighted code blocks, progressive SSE streaming, message editing, and conversation management.

---

## 🏗️ Architecture

OmniChat enforces strict local-first security:
- **No Direct LLM Calls**: Your browser never makes direct API calls to OpenAI, Anthropic, or Google.
- **Backend Security Proxy**: All requests route through a local Node.js Express proxy (`http://localhost:3001`), which stores your OmniRoute API key safely in local SQLite storage.

```
┌───────────────────────────┐
│     Browser Frontend      │ (React 18 + Vite)
│   http://localhost:5173   │
└─────────────┬─────────────┘
              │ Local API Calls / SSE Streams
              ▼
┌───────────────────────────┐
│   Node.js Proxy Backend   │ (Express + SQLite)
│   http://localhost:3001   │
└─────────────┬─────────────┘
              │ OpenAI-Compatible API
              ▼
┌───────────────────────────┐
│     OmniRoute Server      │ (Local Gateway)
│   http://localhost:20128  │
└─────────────┬─────────────┘
              │ Provider Routing
              ▼
┌───────────────────────────┐
│ Configured AI Providers   │ (Claude, Gemini, OpenAI, Ollama, etc.)
└───────────────────────────┘
```

---

## ⚡ Quick Start (Windows Setup)

### Prerequisites
1. **Node.js**: v18.0.0 or higher
2. **npm**: v9.0.0 or higher
3. **OmniRoute**: Installed globally on your machine

### 1. Launch OmniRoute Server
Open a terminal (PowerShell or CMD) and run:
```cmd
omniroute
```
OmniRoute will start listening on `http://localhost:20128/v1`.

### 2. Install & Run OmniChat

Open PowerShell in the `Omnichat` directory and run:

```cmd
# 1. Install dependencies
npm install

# 2. Run backend & frontend concurrently
npm run dev
```

OmniChat will open automatically in your browser at:
**`http://localhost:5173`**

---

## ⚙️ Configuration & Connection

1. Click the **Settings (⚙️)** button in the bottom left or top right of OmniChat.
2. In the **Connection** tab:
   - **OmniRoute Base URL**: Set to `http://localhost:20128/v1` (Default).
   - **OmniRoute API Key**: Enter your OmniRoute API key (if required).
3. Click **Test Connection** to verify reachability.
4. Click **Fetch Models** to populate the model list from OmniRoute.
5. Select **Auto** or a specific model in the top model selector bar.
6. Start chatting!

---

## 🌟 Key Features

- 💬 **ChatGPT/Claude Experience**: Modern responsive interface with sidebar history, search, and customizable light/dark themes.
- ⚡ **Progressive SSE Streaming**: Instant progressive token rendering using Server-Sent Events with stop-generation support.
- 🎯 **Auto Model Option**: Supports sending `model: "auto"` for dynamic model routing by OmniRoute.
- 📝 **Markdown & Code Highlighting**: Rich rendering for tables, lists, blockquotes, and language-tagged code blocks with 1-click **Copy Code**.
- ✏️ **Edit & Regenerate**: Edit previous user messages to branch conversations or click **Regenerate** to get fresh assistant responses.
- 💾 **Local SQLite Storage**: Unlimited persistent conversations stored safely in your local `omnichat.db`.
- 🔍 **Live Diagnostic Checklist**: Built-in connection diagnostic page verifying Base URL, server reachability, auth validity, model discovery, and roundtrip latency.
- 🔌 **Extensible Agent Architecture**: Prepared TypeScript interfaces (`src/agent/types.ts`) for tool execution, file editing, and terminal execution in future agent updates.

---

## 🔧 Troubleshooting

| Symptom | Cause | Solution |
| :--- | :--- | :--- |
| **Status: Disconnected** | OmniRoute server is not running | Run `omniroute` in your terminal |
| **Authentication Failed (401)** | Missing or incorrect OmniRoute API Key | Open Settings -> Connection -> Enter API Key |
| **Backend Unreachable** | Node Express server stopped | Run `npm run dev` to start the backend on port 3001 |
| **Fetch Models Error** | Incorrect Base URL format | Ensure Base URL ends with `/v1` (e.g. `http://localhost:20128/v1`) |

---

## 🛠️ Project File Structure

```
Omnichat/
├── server/
│   ├── index.ts               # Express boot server
│   ├── db.ts                  # SQLite DB layer & persistence
│   ├── config.ts              # Server config loader
│   └── routes/
│       ├── settings.ts        # Settings & reset endpoints
│       ├── omniroute.ts      # OmniRoute health check, models proxy, & SSE stream proxy
│       └── conversations.ts   # History & message CRUD
├── src/
│   ├── agent/                 # Coding agent extensibility types
│   ├── components/
│   │   ├── chat/              # Header, MessageList, MessageItem, Input, CodeBlock, EmptyState
│   │   ├── sidebar/           # History list, search, items
│   │   ├── settings/          # Connection, Models, Appearance, Diagnostic, Help tabs
│   │   └── common/            # Modals, status badges, confirmation dialogs
│   ├── context/               # React SettingsContext & ChatContext
│   ├── services/              # API fetch client & SSE stream reader
│   ├── types/                 # TypeScript interfaces
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css              # Global themes & CSS tokens
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```
