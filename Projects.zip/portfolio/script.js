/**
 * SUMIT SOLANKI — BESPOKE ARCHITECTURAL PORTFOLIO SCRIPT
 * Pure ES6+ JavaScript: CLI Terminal, Particle Canvas, Web Audio Synthesizer,
 * Dual-Mode Engine, Scope Estimator & Deep-Dive Modals.
 */

document.addEventListener('DOMContentLoaded', () => {
  initCyberCanvas();
  initSpotlightCursor();
  initHUDLiveClock();
  initViewMode();
  initTheme();
  initAudioEngine();
  initTypingHeadline();
  initQuickMetrics();
  initInteractiveTerminal();
  initProjectsFilter();
  initProjectModal();
  initScopeEstimator();
  initContactForm();
  initMobileNavigation();
  initScrollTop();
  initFooterYear();
});

/* ==========================================================================
   1. INTERACTIVE CYBER CONSTELLATION CANVAS
   ========================================================================== */
function initCyberCanvas() {
  const canvas = document.getElementById('cyber-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let width = (canvas.width = window.innerWidth);
  let height = (canvas.height = window.innerHeight);

  const particles = [];
  const particleCount = Math.min(Math.floor(width * 0.05), 65);
  const mouse = { x: null, y: null, radius: 140 };

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  });

  window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  });

  window.addEventListener('mouseleave', () => {
    mouse.x = null;
    mouse.y = null;
  });

  class Particle {
    constructor() {
      this.x = Math.random() * width;
      this.y = Math.random() * height;
      this.vx = (Math.random() - 0.5) * 0.7;
      this.vy = (Math.random() - 0.5) * 0.7;
      this.size = Math.random() * 2 + 1;
      this.color = Math.random() > 0.5 ? '#00f0ff' : '#6366f1';
    }

    update() {
      this.x += this.vx;
      this.y += this.vy;

      if (this.x < 0 || this.x > width) this.vx *= -1;
      if (this.y < 0 || this.y > height) this.vy *= -1;

      // Mouse repulsion / interaction
      if (mouse.x && mouse.y) {
        const dx = mouse.x - this.x;
        const dy = mouse.y - this.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < mouse.radius) {
          const force = (mouse.radius - dist) / mouse.radius;
          const dirX = dx / dist;
          const dirY = dy / dist;
          this.x -= dirX * force * 3;
          this.y -= dirY * force * 3;
        }
      }
    }

    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      ctx.fill();
    }
  }

  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }

  function animate() {
    ctx.clearRect(0, 0, width, height);

    for (let i = 0; i < particles.length; i++) {
      particles[i].update();
      particles[i].draw();

      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 110) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(0, 240, 255, ${0.15 - dist / 1100})`;
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(animate);
  }

  animate();
}

/* ==========================================================================
   2. DYNAMIC SPOTLIGHT CURSOR GLOW
   ========================================================================== */
function initSpotlightCursor() {
  const spotlight = document.getElementById('spotlight-cursor');
  if (!spotlight) return;

  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;
  let currentX = mouseX;
  let currentY = mouseY;

  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  function renderSpotlight() {
    currentX += (mouseX - currentX) * 0.15;
    currentY += (mouseY - currentY) * 0.15;
    spotlight.style.left = `${currentX}px`;
    spotlight.style.top = `${currentY}px`;
    requestAnimationFrame(renderSpotlight);
  }

  renderSpotlight();
}

/* ==========================================================================
   3. LIVE HUD TELEMETRY CLOCK
   ========================================================================== */
function initHUDLiveClock() {
  const clockEl = document.getElementById('live-clock');
  const localTimeTag = document.getElementById('local-time-tag');

  function updateClock() {
    const now = new Date();
    const options = { timeZone: 'Asia/Kolkata', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' };
    const istString = now.toLocaleTimeString('en-US', options);
    
    if (clockEl) clockEl.textContent = `${istString} IST`;
    if (localTimeTag) localTimeTag.textContent = `${istString} IST (India)`;
  }

  updateClock();
  setInterval(updateClock, 1000);
}

/* ==========================================================================
   4. DUAL VIEW MODE (Dev Mode vs Recruiter Mode)
   ========================================================================== */
function initViewMode() {
  const toggleBtn = document.getElementById('view-mode-toggle');
  const htmlEl = document.documentElement;

  const savedMode = localStorage.getItem('sumit_view_mode') || 'dev';
  htmlEl.setAttribute('data-view', savedMode);

  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      playSound('switch');
      const current = htmlEl.getAttribute('data-view');
      const newMode = current === 'dev' ? 'recruiter' : 'dev';
      htmlEl.setAttribute('data-view', newMode);
      localStorage.setItem('sumit_view_mode', newMode);

      showCyberToast(
        newMode === 'recruiter' ? 'Recruiter Mode Active' : 'Dev / CLI Mode Active',
        newMode === 'recruiter' ? 'Condensed highlights & executive telemetry enabled.' : 'Interactive UNIX terminal & engineering specs unlocked.'
      );
    });
  }
}

/* ==========================================================================
   5. THEME SWITCHER
   ========================================================================== */
function initTheme() {
  const themeBtn = document.getElementById('theme-toggle');
  const themeIcon = document.getElementById('theme-icon');
  const htmlEl = document.documentElement;

  const savedTheme = localStorage.getItem('sumit_bespoke_theme') || 'dark';
  htmlEl.setAttribute('data-theme', savedTheme);
  updateIcon(savedTheme);

  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      playSound('click');
      const current = htmlEl.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      htmlEl.setAttribute('data-theme', next);
      localStorage.setItem('sumit_bespoke_theme', next);
      updateIcon(next);
    });
  }

  function updateIcon(t) {
    if (!themeIcon) return;
    themeIcon.className = t === 'light' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
    themeIcon.style.color = t === 'light' ? '#f59e0b' : '';
  }
}

/* ==========================================================================
   6. WEB AUDIO SYNTHESIZER ENGINE (Pure Web Audio API - Zero Assets)
   ========================================================================== */
let audioCtx = null;
let soundEnabled = false;

function initAudioEngine() {
  const audioToggleBtn = document.getElementById('audio-toggle');
  const audioIcon = document.getElementById('audio-icon');

  if (audioToggleBtn) {
    audioToggleBtn.addEventListener('click', () => {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      soundEnabled = !soundEnabled;

      if (audioIcon) {
        audioIcon.className = soundEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark';
        audioIcon.style.color = soundEnabled ? '#00f0ff' : '';
      }

      if (soundEnabled) {
        playSound('beep');
        showCyberToast('Audio Synthesizer Activated', 'Interactive haptic audio feedback is now enabled.');
      }
    });
  }
}

function playSound(type) {
  if (!soundEnabled || !audioCtx) return;

  try {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    const now = audioCtx.currentTime;

    if (type === 'click') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.05);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.linearRampToValueAtTime(0, now + 0.05);
      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === 'beep') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(520, now);
      osc.frequency.setValueAtTime(880, now + 0.06);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.linearRampToValueAtTime(0, now + 0.12);
      osc.start(now);
      osc.stop(now + 0.12);
    } else if (type === 'switch') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(900, now + 0.08);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.linearRampToValueAtTime(0, now + 0.08);
      osc.start(now);
      osc.stop(now + 0.08);
    }
  } catch (e) {
    // Audio safe fallback
  }
}

/* ==========================================================================
   7. TYPING HEADLINE EFFECT
   ========================================================================== */
function initTypingHeadline() {
  const target = document.getElementById('hero-typing-target');
  if (!target) return;

  const phrases = [
    "building scalable MERN & cloud architectures...",
    "designing high-throughput REST APIs & WebSocket hubs...",
    "crafting fluid Next.js & responsive client experiences...",
    "optimizing SQL & MongoDB aggregation pipelines...",
    "engineering resilient systems ready for load."
  ];

  let phraseIdx = 0;
  let charIdx = 0;
  let isDeleting = false;

  function loop() {
    const current = phrases[phraseIdx];
    if (!isDeleting) {
      target.textContent = current.substring(0, charIdx + 1);
      charIdx++;
      if (charIdx === current.length) {
        isDeleting = true;
        setTimeout(loop, 2200);
        return;
      }
    } else {
      target.textContent = current.substring(0, charIdx - 1);
      charIdx--;
      if (charIdx === 0) {
        isDeleting = false;
        phraseIdx = (phraseIdx + 1) % phrases.length;
      }
    }
    setTimeout(loop, isDeleting ? 30 : 65);
  }

  loop();
}

/* ==========================================================================
   8. QUICK METRICS NUMERICAL COUNTERS
   ========================================================================== */
function initQuickMetrics() {
  const nums = document.querySelectorAll('.q-num');
  if (!nums.length) return;

  let triggered = false;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !triggered) {
        triggered = true;
        nums.forEach(counter => {
          const target = +counter.getAttribute('data-target');
          let val = 0;
          const step = target / 30;
          const timer = setInterval(() => {
            val += step;
            if (val >= target) {
              counter.textContent = target;
              clearInterval(timer);
            } else {
              counter.textContent = Math.floor(val);
            }
          }, 35);
        });
      }
    });
  }, { threshold: 0.3 });

  const metricsRow = document.querySelector('.hero-quick-metrics');
  if (metricsRow) observer.observe(metricsRow);
}

/* ==========================================================================
   9. INTERACTIVE UNIX CLI TERMINAL ENGINE
   ========================================================================== */
function initInteractiveTerminal() {
  const form = document.getElementById('terminal-form');
  const input = document.getElementById('cli-input');
  const output = document.getElementById('terminal-output');
  const quickBtns = document.querySelectorAll('.terminal-quick-btn');

  if (!form || !input || !output) return;

  const commandHistory = [];
  let historyIndex = -1;

  const commands = {
    help: () => `
Available Commands:
  • <span class="cmd-highlight">projects</span>       - View index of all 11 production systems
  • <span class="cmd-highlight">skills</span>         - Print full technical toolkit & architectural strengths
  • <span class="cmd-highlight">bio</span>            - Display architect philosophy and background
  • <span class="cmd-highlight">contact</span>        - Show transmission links and email
  • <span class="cmd-highlight">estimate</span>       - Jump to interactive project scope estimator
  • <span class="cmd-highlight">hire</span>           - Interrogate freelance & full-time availability
  • <span class="cmd-highlight">clear</span>          - Flush terminal buffer
  • <span class="cmd-highlight">matrix</span>         - Trigger cybernetic matrix sequence
  • <span class="cmd-highlight">sudo [action]</span>  - Execute privileged command
`,
    projects: () => `
=== PRODUCTION SHIPPED SYSTEMS (11 Total) ===
 [01] ShopSphere   -> Full-Stack E-Commerce Engine (React, Node, Mongo, Stripe)
 [02] DevConnect   -> Real-Time Developer Social & Chat (WebSockets, Redis)
 [03] TaskFlow Pro -> Multi-Tenant Kanban Workspace (Next.js, Postgres, Prisma)
 [04] AI Content   -> Autonomous SaaS Copywriting Engine (OpenAI, Express)
 [05] CryptoPulse  -> High-Frequency Market Analytics (React, Chart.js, APIs)
 [06] StreamVibe   -> Chunked Video Streaming Hub (Node, Cloudinary, Mongo)
 [07] MediCare     -> Healthcare Appointment & Records Portal (MERN, SMTP)
 [08] FoodieDash   -> Food Ordering & Live Geospatial Tracker (Leaflet Maps)
 [09] AuthVault    -> Security Auth Microservice (Redis, OAuth2, 2FA, JWT)
 [10] Nexus CRM    -> Sales Pipeline Aggregation Engine (Mongo Pipelines, Docker)
 [11] GitPulse     -> GitHub Analytics & Scorecard (Vanilla JavaScript ES6+)
`,
    skills: () => `
=== TECHNICAL SPECS & STACK ARSENAL ===
  [Frontend]   : React.js, Next.js (App Router), JavaScript (ES6+), Tailwind CSS, Redux
  [Backend]    : Node.js, Express.js, RESTful Architecture, WebSockets (Socket.io)
  [Databases]  : MongoDB (Aggregation/Indexing), PostgreSQL, Prisma ORM, Redis (Caching)
  [Security]   : JWT Access/Refresh Rotation, OAuth2, TOTP 2FA, CORS, Rate Limiting
  [DevOps/Tool]: Git/GitHub, Docker, Postman, Vite, Vercel, Cloudinary
`,
    bio: () => `
Sumit Solanki — Full Stack Systems & Web Architect
Location : India (Available for Worldwide Remote)
Approach : Performance-first, clean code, modular microservices & reactive UIs.
Experience: 3+ Years specializing in complete full-stack web products.
`,
    contact: () => `
DIRECT TRANSMISSION CHANNELS:
  • Email    : sumitsolanki.dev@example.com
  • LinkedIn : linkedin.com/in/sumit-solanki
  • GitHub   : github.com/sumit-solanki
  • Direct   : Scroll to bottom form to send direct transmission.
`,
    hire: () => `
STATUS: AVAILABLE for Full-Time Roles & Select Contract Architectures.
Rate / Terms: Flexible milestone-based or dedicated sprint engagements.
Next Step: Type 'contact' or fill out the Project Estimator!
`,
    matrix: () => `
[SYSTEM HACK INITIATED...]
01001000 01001001 01010010 01000101 00100000 01010011 01010101 01001101 01001001 01010100
Access Granted. Sumit Solanki is ready to build your next breakthrough product.
`,
    clear: () => {
      output.innerHTML = '';
      return '';
    }
  };

  function executeCommand(rawCmd) {
    const cleanCmd = rawCmd.trim().toLowerCase();
    if (!cleanCmd) return;

    playSound('click');
    commandHistory.push(cleanCmd);
    historyIndex = commandHistory.length;

    // Echo input
    const line = document.createElement('div');
    line.className = 'term-cmd-entry';
    line.innerHTML = `<span class="term-prompt">sumit@terminal:~$</span> ${escapeHTML(rawCmd)}`;
    output.appendChild(line);

    // Process output
    let responseText = '';
    if (cleanCmd in commands) {
      responseText = commands[cleanCmd]();
    } else if (cleanCmd.startsWith('sudo')) {
      responseText = `Permission granted. Executing '${escapeHTML(cleanCmd)}'... Done. Welcome, Superuser.`;
    } else if (cleanCmd === 'estimate') {
      document.getElementById('estimator')?.scrollIntoView({ behavior: 'smooth' });
      responseText = `Navigating to Project Scope Estimator...`;
    } else {
      responseText = `command not found: ${escapeHTML(cleanCmd)}. Type <span class="cmd-highlight">help</span> for list of commands.`;
    }

    if (responseText) {
      const resp = document.createElement('div');
      resp.className = 'term-cmd-response';
      resp.innerHTML = responseText;
      output.appendChild(resp);
    }

    const screen = document.getElementById('terminal-screen');
    if (screen) screen.scrollTop = screen.scrollHeight;
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const val = input.value;
    input.value = '';
    executeCommand(val);
  });

  // Quick Command Buttons
  quickBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const cmd = btn.getAttribute('data-cmd');
      executeCommand(cmd);
    });
  });

  // History Navigation via Arrow Keys
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowUp') {
      if (historyIndex > 0) {
        historyIndex--;
        input.value = commandHistory[historyIndex] || '';
      }
    } else if (e.key === 'ArrowDown') {
      if (historyIndex < commandHistory.length - 1) {
        historyIndex++;
        input.value = commandHistory[historyIndex] || '';
      } else {
        historyIndex = commandHistory.length;
        input.value = '';
      }
    }
  });

  function escapeHTML(str) {
    return str.replace(/[&<>'"]/g, tag => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[tag] || tag));
  }
}

/* ==========================================================================
   10. PROJECTS FILTER SYSTEM
   ========================================================================== */
function initProjectsFilter() {
  const filterBtns = document.querySelectorAll('.b-filter-btn');
  const projectCards = document.querySelectorAll('.system-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      playSound('click');
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-filter');

      projectCards.forEach(card => {
        const cat = card.getAttribute('data-category') || '';
        if (filter === 'all' || cat.includes(filter)) {
          card.classList.remove('hide');
        } else {
          card.classList.add('hide');
        }
      });
    });
  });
}

/* ==========================================================================
   11. BESPOKE PROJECT DEEP-DIVE MODAL
   ========================================================================== */
const bespokeProjectsDB = {
  shopsphere: {
    title: "ShopSphere — Full-Stack E-Commerce Engine",
    category: "Full Stack MERN & Financial Pipeline",
    bannerClass: "banner-ecom",
    icon: "fa-solid fa-bag-shopping",
    tags: ["React.js", "Node.js", "Express", "MongoDB", "Stripe API", "Redux Toolkit", "JWT"],
    description: "ShopSphere is an end-to-end commerce architecture engineered to handle complex catalogs, multi-criteria real-time filtering, atomic shopping carts, and webhooks.",
    specs: [
      "Optimized MongoDB indexing for sub-20ms search across high volume products",
      "Stripe Webhook reconciliation ensuring zero dropped checkout transactions",
      "Stateless JWT auth with refresh token rotation and HTTP-only cookies",
      "Admin analytics telemetry tracking live sales, margin velocity & inventory replenishment",
      "Fluid responsive UI built with pure CSS custom variables and zero runtime overhead"
    ],
    github: "https://github.com",
    demo: "#"
  },
  devconnect: {
    title: "DevConnect — Real-Time Developer Social & Chat",
    category: "WebSockets & Event-Driven Architecture",
    bannerClass: "banner-chat",
    icon: "fa-solid fa-comments",
    tags: ["Socket.io", "React.js", "Node.js", "MongoDB", "Cloudinary Media", "Express"],
    description: "A collaborative social platform for developers featuring bi-directional real-time chat rooms, code snippet highlight sharing, and media compression pipelines.",
    specs: [
      "Custom Socket.io room orchestration supporting high concurrent connections",
      "Real-time event broadcasting for code updates, likes, and typing indicators",
      "Automatic code syntax detection across 30+ programming languages",
      "Cloudinary SDK integration with on-the-fly image transformations",
      "Optimized client state caching to minimize redundant network round-trips"
    ],
    github: "https://github.com",
    demo: "#"
  },
  taskflow: {
    title: "TaskFlow Pro — Multi-Tenant Kanban Workspace",
    category: "Next.js & Relational PostgreSQL Systems",
    bannerClass: "banner-kanban",
    icon: "fa-solid fa-table-columns",
    tags: ["Next.js (App Router)", "PostgreSQL", "Prisma ORM", "Tailwind CSS", "NextAuth"],
    description: "Enterprise project management engine built with strict relational schemas, multi-tenant workspace isolation, and drag-and-drop workflow kanban boards.",
    specs: [
      "PostgreSQL relational modeling with foreign keys, cascaded deletes & ACID guarantees",
      "NextAuth session handling with enterprise Role-Based Access Control (RBAC)",
      "Smooth 60fps drag-and-drop task manipulation using DnD Kit",
      "Complete immutable activity audit trail logging every state modification",
      "Server-Side Rendering (SSR) for initial load speeds under 400ms"
    ],
    github: "https://github.com",
    demo: "#"
  },
  aicontent: {
    title: "AI ContentForge — SaaS Copywriting Engine",
    category: "AI LLM Integration & SaaS Monetization",
    bannerClass: "banner-ai",
    icon: "fa-solid fa-brain",
    tags: ["OpenAI API / Gemini", "React", "Express", "MongoDB", "Stripe Billing"],
    description: "Autonomous content generation and SEO intelligence tool leveraging fine-tuned system prompts, streaming token outputs, and Stripe subscription tiering.",
    specs: [
      "Streamed server-sent events (SSE) for real-time word-by-word token printing",
      "Stripe Subscription webhooks managing monthly token allowances & usage quotas",
      "Prompt template manager generating high-converting ad copy and blog outlines",
      "Saved generation history with one-click Markdown & PDF document exports",
      "Cyberpunk dark-themed dashboard interface with fluid micro-interactions"
    ],
    github: "https://github.com",
    demo: "#"
  },
  cryptopulse: {
    title: "CryptoPulse — High-Frequency Market Dashboard",
    category: "Financial Analytics & Reactive Canvas",
    bannerClass: "banner-crypto",
    icon: "fa-solid fa-chart-line",
    tags: ["React.js", "Chart.js", "CoinGecko REST API", "Axios", "Local Storage"],
    description: "Live cryptocurrency market tracking dashboard monitoring 500+ assets with interactive historical candlestick visuals, conversion calculators, and watchlists.",
    specs: [
      "Reactive Chart.js canvas rendering 24h, 7d, and 1y historical price graphs",
      "Debounced live API querying with local cache to avoid rate-limiting triggers",
      "Multi-currency conversion engine supporting USD, EUR, INR, and GBP",
      "Persistent user watchlists stored safely in browser localStorage",
      "100% mobile responsive touch-friendly layout"
    ],
    github: "https://github.com",
    demo: "#"
  },
  streamvibe: {
    title: "StreamVibe — Chunked Video Delivery Platform",
    category: "Media Streaming & Cloud Processing",
    bannerClass: "banner-video",
    icon: "fa-solid fa-video",
    tags: ["Node.js", "Express", "MongoDB", "Cloudinary Video", "React.js"],
    description: "Video publishing and streaming hub designed with chunked video upload pipelines, channel customizations, threaded comment trees, and search indexing.",
    specs: [
      "Chunked streaming buffer delivering continuous playback without stutter",
      "Creator channel portals with custom banners, avatars, and subscriber stats",
      "Recursive nested comment algorithms supporting infinite reply depths",
      "Custom HTML5 video controller with speed, quality, and theater controls",
      "MongoDB text search indexing for instant video title & tag discovery"
    ],
    github: "https://github.com",
    demo: "#"
  },
  medicare: {
    title: "MediCare — Doctor Appointment & Patient Records",
    category: "Full Stack Healthcare Ecosystem",
    bannerClass: "banner-health",
    icon: "fa-solid fa-notes-medical",
    tags: ["MERN Stack", "Nodemailer", "JWT Auth", "Tailwind CSS"],
    description: "Healthcare operations portal connecting patients with specialized medical practitioners, featuring real-time appointment booking, and SMTP notifications.",
    specs: [
      "Collision-free appointment slot locking to eliminate double-booking bugs",
      "Automated transactional confirmation and reminder emails via Nodemailer SMTP",
      "Secure patient medical document archive with encrypted access",
      "Specialty filtering by department, consultation pricing, and verified reviews",
      "Doctor dashboard for managing daily queues and patient consult notes"
    ],
    github: "https://github.com",
    demo: "#"
  },
  foodiedash: {
    title: "FoodieDash — Food Ordering & Live Geospatial Tracker",
    category: "Frontend Architecture & Maps API",
    bannerClass: "banner-food",
    icon: "fa-solid fa-utensils",
    tags: ["React.js", "Redux Toolkit", "Leaflet Maps API", "CSS Grid"],
    description: "Fast food delivery application with dietary menus, global Redux state computations, and simulated real-time GPS courier route animation.",
    specs: [
      "Interactive restaurant menu with instant category & dietary constraint filters",
      "Predictable global cart calculations powered by Redux Toolkit slices",
      "Leaflet & OpenStreetMap geospatial route tracking simulator",
      "Dynamic promo discount application engine with validation rules",
      "Smooth touch gesture ergonomics on mobile devices"
    ],
    github: "https://github.com",
    demo: "#"
  },
  authvault: {
    title: "AuthVault — Security Authentication Microservice",
    category: "Backend Security & Distributed Caching",
    bannerClass: "banner-auth",
    icon: "fa-solid fa-shield-halved",
    tags: ["Node.js", "Express", "Redis", "PostgreSQL", "OAuth2", "Swagger"],
    description: "Production-ready standalone authentication microservice featuring token rotation, Redis caching, two-factor authentication (2FA), and Swagger documentation.",
    specs: [
      "Short-lived JWT Access Tokens with rotating Refresh Tokens stored in Redis",
      "OAuth 2.0 social authorization for Google, GitHub, and Discord providers",
      "Two-Factor Authentication (2FA) with TOTP / Google Authenticator QR generation",
      "IP-based and user-based Redis rate-limiting to prevent brute force threats",
      "Comprehensive interactive API testing playground via Swagger UI"
    ],
    github: "https://github.com",
    demo: "#"
  },
  nexuscrm: {
    title: "Nexus CRM — Sales Pipeline & Analytics Engine",
    category: "Backend Architecture & Data Pipelines",
    bannerClass: "banner-crm",
    icon: "fa-solid fa-chart-pie",
    tags: ["Node.js", "MongoDB", "Aggregation Pipelines", "Docker"],
    description: "Scalable CRM backend engine powered by complex multi-stage MongoDB aggregation pipelines for sales forecasting, lead scoring, and streaming CSV exports.",
    specs: [
      "Multi-stage MongoDB aggregation pipelines computing real-time deal conversions",
      "Streaming CSV parser supporting bulk lead uploads without RAM spikes",
      "Customizable Kanban deal stages with automated webhook event triggers",
      "Dockerized container configuration for zero-friction staging deployments",
      "Clean modular Controller-Service-Repository architecture"
    ],
    github: "https://github.com",
    demo: "#"
  },
  gitpulse: {
    title: "GitPulse — GitHub Analytics & Developer Scorecard",
    category: "Pure Vanilla ES6+ & Data Visualization",
    bannerClass: "banner-git",
    icon: "fa-brands fa-github",
    tags: ["JavaScript (ES6+)", "GitHub REST API", "Chart.js", "CSS3"],
    description: "Zero-framework developer portfolio analyzer fetching commit velocities, repository distributions, and language heatmaps via GitHub REST API.",
    specs: [
      "Direct asynchronous communication with GitHub REST endpoints",
      "Visual chart rendering of programming language distribution across repos",
      "Shareable developer metrics scorecard generation",
      "Engineered completely in dependency-free modern vanilla JavaScript",
      "Ultra-lightweight bundle size under 25KB total"
    ],
    github: "https://github.com",
    demo: "#"
  }
};

function initProjectModal() {
  const modal = document.getElementById('details-modal');
  const modalArea = document.getElementById('modal-content-area');
  const closeBtn = document.getElementById('modal-close-btn');
  const triggers = document.querySelectorAll('.btn-sys-details');

  if (!modal || !modalArea) return;

  triggers.forEach(btn => {
    btn.addEventListener('click', () => {
      playSound('click');
      const id = btn.getAttribute('data-modal');
      const project = bespokeProjectsDB[id];
      if (!project) return;

      modalArea.innerHTML = `
        <div class="modal-header-hero ${project.bannerClass}">
          <i class="${project.icon}"></i>
        </div>
        <h3 class="m-title">${project.title}</h3>
        <p class="m-sub"><i class="fa-solid fa-layer-group"></i> ${project.category}</p>
        
        <div class="m-tags">
          ${project.tags.map(t => `<span>${t}</span>`).join('')}
        </div>

        <p class="m-desc">${project.description}</p>

        <div class="m-spec-block">
          <h4><i class="fa-solid fa-microchip"></i> Architectural Highlights:</h4>
          <ul>
            ${project.specs.map(s => `<li>${s}</li>`).join('')}
          </ul>
        </div>

        <div class="m-actions">
          <a href="${project.github}" target="_blank" rel="noopener noreferrer" class="btn-bespoke btn-secondary">
            <i class="fa-brands fa-github"></i> Inspect Source
          </a>
          <a href="${project.demo}" class="btn-bespoke btn-glow">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Launch Live Application
          </a>
        </div>
      `;

      modal.classList.add('active');
      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    });
  });

  function closeModal() {
    playSound('click');
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-backdrop-blur')) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('active')) closeModal();
  });
}

/* ==========================================================================
   12. INTERACTIVE SCOPE ESTIMATOR
   ========================================================================== */
function initScopeEstimator() {
  const typeChips = document.querySelectorAll('#opt-type .est-chip');
  const moduleChecks = document.querySelectorAll('#opt-modules input[type="checkbox"]');
  const timeOutput = document.getElementById('est-total-time');
  const stackOutput = document.getElementById('est-stack-name');
  const tierOutput = document.getElementById('est-tier-name');
  const applyBtn = document.getElementById('apply-to-contact-btn');

  if (!typeChips.length) return;

  function calculateScope() {
    let baseWeeks = 3;
    let selectedStack = "Next.js + Postgres + Stripe";
    let tier = "Production Multi-Tenant";

    const activeType = document.querySelector('#opt-type .est-chip.active');
    if (activeType) {
      baseWeeks = +activeType.getAttribute('data-weeks') || 3;
      selectedStack = activeType.getAttribute('data-stack') || selectedStack;
      const type = activeType.getAttribute('data-type');
      if (type === 'mvp') tier = "Rapid Prototype (Phase 1)";
      if (type === 'api') tier = "High-Throughput Microservice";
      if (type === 'ecom') tier = "Full-Scale Commerce Engine";
      if (type === 'saas') tier = "Production Multi-Tenant SaaS";
    }

    let extraDays = 0;
    moduleChecks.forEach(chk => {
      if (chk.checked) {
        extraDays += +chk.getAttribute('data-add-days') || 1;
      }
    });

    const totalWeeks = Math.ceil(baseWeeks + extraDays / 5);
    const minWeeks = Math.max(1, totalWeeks - 1);

    if (timeOutput) timeOutput.textContent = `${minWeeks} - ${totalWeeks} Weeks`;
    if (stackOutput) stackOutput.textContent = selectedStack;
    if (tierOutput) tierOutput.textContent = tier;
  }

  typeChips.forEach(chip => {
    chip.addEventListener('click', () => {
      playSound('click');
      typeChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      calculateScope();
    });
  });

  moduleChecks.forEach(chk => {
    chk.addEventListener('change', () => {
      playSound('click');
      calculateScope();
    });
  });

  calculateScope();

  // "Discuss This Scope" pre-populates contact form
  if (applyBtn) {
    applyBtn.addEventListener('click', () => {
      playSound('beep');
      const activeType = document.querySelector('#opt-type .est-chip.active')?.textContent.trim() || 'Custom Project';
      const stack = stackOutput?.textContent || '';
      const time = timeOutput?.textContent || '';

      const subjInput = document.getElementById('contact-subject');
      const msgInput = document.getElementById('contact-message');

      if (subjInput) subjInput.value = `Project Scope Inquiry: ${activeType}`;
      if (msgInput) {
        msgInput.value = `Hi Sumit,\n\nI used your Project Scope Estimator for a "${activeType}".\n- Recommended Stack: ${stack}\n- Estimated Timeline: ${time}\n\nLet's schedule a call to discuss architecture and requirements!`;
      }

      document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    });
  }
}

/* ==========================================================================
   13. BESPOKE CONTACT FORM VALIDATION & SUBMISSION
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById('bespoke-contact-form');
  const submitBtn = document.getElementById('contact-submit-btn');

  if (!form) return;

  const nameIn = document.getElementById('contact-name');
  const emailIn = document.getElementById('contact-email');
  const subjIn = document.getElementById('contact-subject');
  const msgIn = document.getElementById('contact-message');

  const errName = document.getElementById('err-name');
  const errEmail = document.getElementById('err-email');
  const errSubj = document.getElementById('err-subject');
  const errMessage = document.getElementById('err-message');

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).toLowerCase());
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;

    // Reset errors
    [errName, errEmail, errSubj, errMessage].forEach(err => {
      if (err) { err.textContent = ''; err.classList.remove('show'); }
    });
    form.querySelectorAll('.f-input-wrap').forEach(w => w.classList.remove('error'));

    if (!nameIn.value.trim()) {
      showErr(nameIn, errName, 'Please enter your name');
      valid = false;
    }

    if (!emailIn.value.trim() || !validateEmail(emailIn.value.trim())) {
      showErr(emailIn, errEmail, 'Please provide a valid email');
      valid = false;
    }

    if (!subjIn.value.trim()) {
      showErr(subjIn, errSubj, 'Please enter a subject');
      valid = false;
    }

    if (!msgIn.value.trim() || msgIn.value.trim().length < 10) {
      showErr(msgIn, errMessage, 'Message must be at least 10 characters');
      valid = false;
    }

    if (!valid) return;

    submitBtn.classList.add('loading');
    submitBtn.disabled = true;

    setTimeout(() => {
      submitBtn.classList.remove('loading');
      submitBtn.disabled = false;
      playSound('beep');

      showCyberToast(
        'Transmission Dispatched',
        `Thank you ${nameIn.value.trim()}! Sumit has received your project briefing.`
      );

      form.reset();
    }, 1200);
  });

  function showErr(input, errEl, msg) {
    input.closest('.f-input-wrap')?.classList.add('error');
    if (errEl) {
      errEl.textContent = msg;
      errEl.classList.add('show');
    }
  }
}

/* ==========================================================================
   14. CYBER TOAST NOTIFICATIONS
   ========================================================================== */
function showCyberToast(title, body) {
  const toast = document.getElementById('cyber-toast');
  const tTitle = document.getElementById('toast-title');
  const tBody = document.getElementById('toast-body');

  if (!toast) return;

  if (tTitle) tTitle.textContent = title;
  if (tBody) tBody.textContent = body;

  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 4800);
}

/* ==========================================================================
   15. MOBILE NAVIGATION
   ========================================================================== */
function initMobileNavigation() {
  const btn = document.getElementById('mobile-menu-btn');
  const navLinks = document.querySelector('.nav-links');

  if (!btn || !navLinks) return;

  btn.addEventListener('click', () => {
    playSound('click');
    navLinks.classList.toggle('open');
  });

  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
    });
  });
}

/* ==========================================================================
   16. SCROLL TO TOP & YEAR
   ========================================================================== */
function initScrollTop() {
  const btn = document.getElementById('scroll-top-btn');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    if (window.pageYOffset > 400) {
      btn.classList.add('show');
    } else {
      btn.classList.remove('show');
    }
  });
}

function initFooterYear() {
  const y = document.getElementById('f-year');
  if (y) y.textContent = new Date().getFullYear();
}
