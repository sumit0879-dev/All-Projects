@echo off
title Sumit Solanki Portfolio Server
echo ========================================================
echo   Starting Sumit Solanki Portfolio Local Server...
echo ========================================================
echo.
start http://localhost:3000
node server.js
pause
