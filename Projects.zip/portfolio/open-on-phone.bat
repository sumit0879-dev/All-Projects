@echo off
title Mobile Live Forwarder - Sumit Solanki Portfolio
echo ======================================================================
echo   Starting Public Live Forwarder for Mobile Phones (Any Network)...
echo ======================================================================
echo.
echo Forwarding http://localhost:3000 to public internet...
echo.
ssh -o StrictHostKeyChecking=no -R 80:localhost:3000 nokey@localhost.run
pause
