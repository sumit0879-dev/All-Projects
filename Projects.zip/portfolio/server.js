const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0'; // Allow access from mobile phones & local network

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function getLocalIPs() {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        addresses.push({ name, address: net.address });
      }
    }
  }
  return addresses;
}

const server = http.createServer((req, res) => {
  // Add CORS headers so mobile devices can access with zero restriction
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');

  let reqPath = req.url.split('?')[0];
  if (reqPath === '/') reqPath = '/index.html';

  const filePath = path.join(__dirname, reqPath);
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

server.listen(PORT, HOST, () => {
  const ips = getLocalIPs();
  console.log('\n' + '='.repeat(58));
  console.log('🚀 SUMIT SOLANKI PORTFOLIO SERVER IS LIVE!');
  console.log('='.repeat(58));
  console.log(`\n💻 On your PC / Laptop : http://localhost:${PORT}`);
  
  if (ips.length > 0) {
    console.log(`\n📱 On your Mobile Phone (Same Wi-Fi / Hotspot):`);
    ips.forEach(ip => {
      console.log(`   👉 http://${ip.address}:${PORT}`);
    });
  } else {
    console.log(`\n📱 Make sure your PC and Phone are connected to same Wi-Fi / Hotspot.`);
  }

  console.log('\n' + '='.repeat(58));
  console.log('Press Ctrl + C to stop the server\n');
});
